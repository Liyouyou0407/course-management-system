import { request } from './request'
import type {
  AdminActivity,
  AdminCoursePayload,
  AdminCourseRow,
  AdminDepartment,
  AdminHotCourse,
  AdminStats,
  AdminStudentDetail,
  AdminStudentRow,
  AdminTrendPoint,
  PageResult,
} from '@/types/course'

export function fetchAdminStats() {
  return request<AdminStats>('/admin/stats')
}

export function fetchEnrollmentTrend(months = 6) {
  return request<{ months: number; points: AdminTrendPoint[] }>(
    `/admin/enrollment-trend?months=${months}`,
  )
}

export function fetchAdminActivities(limit = 8) {
  return request<AdminActivity[]>(`/admin/activities?limit=${limit}`)
}

export function fetchHotCourses(limit = 5) {
  return request<AdminHotCourse[]>(`/admin/hot-courses?limit=${limit}`)
}

export function fetchAdminDepartments() {
  return request<AdminDepartment[]>('/admin/departments')
}

export function fetchAdminCourses(params: {
  page?: number
  page_size?: number
  keyword?: string
}) {
  const q = new URLSearchParams()
  if (params.page) q.set('page', String(params.page))
  if (params.page_size) q.set('page_size', String(params.page_size))
  if (params.keyword) q.set('keyword', params.keyword)
  return request<PageResult<AdminCourseRow>>(`/admin/courses?${q.toString()}`)
}

export function createAdminCourse(payload: AdminCoursePayload) {
  return request<{ id: number; status: string }>('/admin/courses', {
    method: 'POST',
    body: JSON.stringify(payload),
  })
}

export function updateAdminCourse(id: number, payload: Partial<AdminCoursePayload>) {
  return request<{ id: number; status: string }>(`/admin/courses/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(payload),
  })
}

export function updateCourseStatus(id: number, status: 'published' | 'draft' | 'archived') {
  return request<{ id: number; status: string }>(`/admin/courses/${id}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  })
}

export function fetchAdminStudents(params: {
  page?: number
  page_size?: number
  keyword?: string
  department_id?: number
}) {
  const q = new URLSearchParams()
  if (params.page) q.set('page', String(params.page))
  if (params.page_size) q.set('page_size', String(params.page_size))
  if (params.keyword) q.set('keyword', params.keyword)
  if (params.department_id) q.set('department_id', String(params.department_id))
  return request<PageResult<AdminStudentRow>>(`/admin/students?${q.toString()}`)
}

export function fetchAdminStudentDetail(id: number) {
  return request<AdminStudentDetail>(`/admin/students/${id}`)
}
