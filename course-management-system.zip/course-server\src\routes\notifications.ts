import { Router } from 'express'
import { prisma } from '../lib/prisma'
import { ok } from '../lib/response'
import { authRequired, type AuthRequest } from '../middleware/auth'

const router = Router()

function formatTime(d: Date) {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  const hh = String(d.getHours()).padStart(2, '0')
  const mm = String(d.getMinutes()).padStart(2, '0')
  return `${y}-${m}-${day} ${hh}:${mm}`
}

router.get('/', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const list = await prisma.notification.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
  })
  return ok(
    res,
    list.map((n) => ({
      id: n.id,
      title: n.title,
      content: n.content || '',
      type: n.type,
      read: n.isRead,
      time: formatTime(n.createdAt),
    })),
  )
})

router.get('/unread-count', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const count = await prisma.notification.count({
    where: { userId, isRead: false },
  })
  return ok(res, { count })
})

router.patch('/read-all', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  await prisma.notification.updateMany({
    where: { userId, isRead: false },
    data: { isRead: true },
  })
  return ok(res, { ok: true })
})

export default router
