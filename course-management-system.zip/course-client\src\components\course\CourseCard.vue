<template>
  <article class="course-card" @click="$emit('click')">
    <div class="course-card__cover" :style="{ background: course.coverGradient }">
      <StatusBadge v-if="course.isHot" label="热门" type="hot" class="course-card__tag" />
      <StatusBadge
        v-else-if="course.isLive"
        label="直播课"
        type="live"
        class="course-card__tag"
      />
      <button
        type="button"
        class="course-card__fav"
        :class="{ on: course.isFavorited }"
        :aria-label="course.isFavorited ? '取消收藏' : '收藏课程'"
        @click.stop="$emit('toggle-favorite', course)"
      >
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path
            d="M12 20s-7-4.35-7-10a4 4 0 017-2.65A4 4 0 0119 10c0 5.65-7 10-7 10z"
            :fill="course.isFavorited ? 'currentColor' : 'none'"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linejoin="round"
          />
        </svg>
      </button>
      <div class="course-card__cover-art" aria-hidden="true">
        <svg viewBox="0 0 80 64" fill="none">
          <rect x="10" y="18" width="48" height="36" rx="4" fill="rgba(255,255,255,0.35)" />
          <path d="M22 30h24M22 38h16" stroke="rgba(255,255,255,0.8)" stroke-width="2" />
          <circle cx="58" cy="22" r="10" fill="rgba(255,255,255,0.25)" />
        </svg>
      </div>
    </div>
    <div class="course-card__body">
      <h3 class="course-card__title">{{ course.title }}</h3>
      <div class="course-card__meta-row">
        <p class="course-card__meta">讲师：{{ course.lecturerName }}</p>
        <p v-if="course.ratingCount > 0 && ratingText" class="course-card__rating">
          ⭐ {{ ratingText }}
          <span>({{ course.ratingCount }}人)</span>
        </p>
      </div>

      <template v-if="variant === 'center'">
        <p class="course-card__row">
          <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <rect x="2" y="3" width="12" height="11" rx="1.5" stroke="currentColor" stroke-width="1.2" />
            <path d="M2 6.5h12M5 1.5v3M11 1.5v3" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" />
          </svg>
          {{ course.plannedDate }}({{ course.weekday }}) {{ course.startTime }}-{{ course.endTime }}
        </p>
        <div class="course-card__footer">
          <span class="course-card__count">
            <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <circle cx="8" cy="5.5" r="2.5" stroke="currentColor" stroke-width="1.2" />
              <path d="M3 13c.8-2.2 2.5-3.3 5-3.3S12.2 10.8 13 13" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" />
            </svg>
            {{ course.studentCount }}人报名
          </span>
          <button type="button" class="btn btn-primary course-card__btn" @click.stop="$emit('enroll', course)">
            {{ course.isEnrolled ? '已报名' : '立即报名' }}
          </button>
        </div>
      </template>

      <template v-else>
        <div class="course-card__footer home-footer">
          <span class="course-card__count">
            <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <circle cx="8" cy="5.5" r="2.5" stroke="currentColor" stroke-width="1.2" />
              <path d="M3 13c.8-2.2 2.5-3.3 5-3.3S12.2 10.8 13 13" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" />
            </svg>
            {{ course.studentCount }}人报名
          </span>
          <span class="course-card__status" :class="course.statusLabel">
            {{ statusText }}
          </span>
        </div>
      </template>
    </div>
  </article>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { Course } from '@/types/course'
import StatusBadge from '@/components/common/StatusBadge.vue'

const props = withDefaults(
  defineProps<{
    course: Course
    variant?: 'home' | 'center'
  }>(),
  { variant: 'home' },
)

defineEmits<{
  click: []
  enroll: [course: Course]
  'toggle-favorite': [course: Course]
}>()

const statusText = computed(() => {
  if (props.course.statusLabel === 'learning') return '学习中'
  if (props.course.statusLabel === 'completed') return '已完成'
  return '报名中'
})

const ratingText = computed(() => {
  const n =
    typeof props.course.ratingAvg === 'number'
      ? props.course.ratingAvg
      : Number(props.course.ratingAvg)
  return Number.isFinite(n) ? n.toFixed(1) : ''
})
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.course-card {
  @include card;
  overflow: hidden;
  cursor: pointer;
  background: #fff;
}

.course-card__cover {
  position: relative;
  height: 140px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.course-card__tag {
  position: absolute;
  top: 10px;
  left: 10px;
  z-index: 1;
}

.course-card__fav {
  position: absolute;
  top: 8px;
  right: 8px;
  z-index: 2;
  width: 32px;
  height: 32px;
  border: none;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.92);
  color: #9ca3af;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
  transition: color 0.15s ease, transform 0.15s ease;

  svg {
    width: 18px;
    height: 18px;
  }

  &:hover {
    color: #ef4444;
    transform: scale(1.05);
  }

  &.on {
    color: #ef4444;
  }
}

.course-card__cover-art {
  width: 72px;
  opacity: 0.95;
}

.course-card__body {
  padding: 14px 16px 16px;
}

.course-card__title {
  font-size: 15px;
  font-weight: 600;
  color: $text-title;
  line-height: 1.4;
  margin-bottom: 8px;
  @include text-ellipsis(2);
  min-height: 42px;
}

.course-card__meta-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
}

.course-card__meta {
  font-size: 13px;
  color: $text-secondary;
  min-width: 0;
  @include text-ellipsis(1);
}

.course-card__rating {
  flex-shrink: 0;
  font-size: 12px;
  color: #d97706;
  white-space: nowrap;

  span {
    color: $text-muted;
    margin-left: 2px;
  }
}

.course-card__row {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: $text-muted;
  margin-bottom: 12px;

  svg {
    width: 14px;
    height: 14px;
    flex-shrink: 0;
  }
}

.course-card__footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.home-footer {
  margin-top: 4px;
  padding-top: 10px;
  border-top: 1px solid #f3f4f8;
}

.course-card__count {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: $text-muted;

  svg {
    width: 14px;
    height: 14px;
  }
}

.course-card__btn {
  height: 32px;
  padding: 0 12px;
  font-size: 13px;
}

.course-card__status {
  font-size: 13px;
  font-weight: 500;

  &.enrolling {
    color: $success;
  }

  &.learning {
    color: $primary;
  }

  &.completed {
    color: $text-muted;
  }
}
</style>
