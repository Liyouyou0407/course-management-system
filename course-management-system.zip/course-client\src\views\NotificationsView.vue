<template>
  <div class="page page-container">
    <div class="page__head">
      <h1>消息通知</h1>
      <button
        type="button"
        class="btn btn-soft"
        :disabled="loading || items.length === 0"
        @click="markAll"
      >
        全部已读
      </button>
    </div>
    <p v-if="error" class="page__error">{{ error }}</p>
    <p v-else-if="loading" class="page__hint">加载中…</p>
    <p v-else-if="items.length === 0" class="page__hint">暂无消息</p>
    <div v-else class="list">
      <article v-for="item in items" :key="item.id" class="item" :class="{ unread: !item.read }">
        <h3>{{ item.title }}</h3>
        <p>{{ item.content }}</p>
        <span>{{ item.time }}</span>
      </article>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { fetchNotifications, type NotificationItem } from '@/api/notifications'
import { useNotificationStore } from '@/stores/notification'

const store = useNotificationStore()
const items = ref<NotificationItem[]>([])
const loading = ref(false)
const error = ref('')

async function load() {
  loading.value = true
  error.value = ''
  try {
    items.value = await fetchNotifications()
    await store.refreshUnread()
  } catch (e) {
    error.value = e instanceof Error ? e.message : '加载失败'
  } finally {
    loading.value = false
  }
}

async function markAll() {
  try {
    await store.markAllRead()
    items.value = items.value.map((i) => ({ ...i, read: true }))
  } catch (e) {
    error.value = e instanceof Error ? e.message : '操作失败'
  }
}

onMounted(load)
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.page__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 18px;

  h1 {
    font-size: 20px;
    color: $text-title;
  }
}

.page__error {
  color: #ef4444;
  font-size: 13px;
  margin-bottom: 12px;
}

.page__hint {
  color: $text-muted;
  font-size: 14px;
}

.list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.item {
  @include card;
  padding: 16px 18px;
  background: #fff;

  h3 {
    font-size: 15px;
    margin-bottom: 6px;
    color: $text-title;
  }

  p {
    font-size: 13px;
    color: $text-secondary;
    margin-bottom: 8px;
    line-height: 1.5;
  }

  span {
    font-size: 12px;
    color: $text-muted;
  }

  &.unread {
    border-left: 3px solid $primary;
  }
}
</style>
