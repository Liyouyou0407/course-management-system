<template>
  <div class="search-bar">
    <div class="search-bar__input-wrap">
      <svg class="search-bar__icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2" />
        <path d="M20 20l-3.5-3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
      </svg>
      <input
        class="search-bar__input"
        type="search"
        :value="modelValue"
        :placeholder="placeholder"
        @input="onInput"
      />
    </div>
    <button v-if="showFilter" type="button" class="search-bar__filter" @click="$emit('filter')">
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path
          d="M4 6h16M7 12h10M10 18h4"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
        />
      </svg>
      筛选
    </button>
  </div>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    modelValue?: string
    placeholder?: string
    showFilter?: boolean
  }>(),
  {
    modelValue: '',
    placeholder: '搜索课程名称、讲师或关键词',
    showFilter: true,
  },
)

const emit = defineEmits<{
  'update:modelValue': [value: string]
  filter: []
}>()

function onInput(e: Event) {
  emit('update:modelValue', (e.target as HTMLInputElement).value)
}
</script>

<style scoped lang="scss">
.search-bar {
  display: flex;
  gap: 12px;
  align-items: center;
}

.search-bar__input-wrap {
  position: relative;
  flex: 1;
}

.search-bar__icon {
  position: absolute;
  left: 14px;
  top: 50%;
  width: 18px;
  height: 18px;
  transform: translateY(-50%);
  color: $text-muted;
}

.search-bar__input {
  width: 100%;
  height: 44px;
  padding: 0 16px 0 42px;
  border: 1px solid $border;
  border-radius: 10px;
  background: #fff;
  font-size: 14px;
  color: $text-body;
  outline: none;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;

  &::placeholder {
    color: $text-placeholder;
  }

  &:focus {
    border-color: $primary;
    box-shadow: 0 0 0 3px rgba(45, 91, 255, 0.12);
  }
}

.search-bar__filter {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 44px;
  padding: 0 16px;
  border: 1px solid $border;
  border-radius: 10px;
  background: #fff;
  color: $text-secondary;
  font-size: 14px;
  cursor: pointer;
  transition: color 0.2s ease, border-color 0.2s ease, background 0.2s ease;

  svg {
    width: 16px;
    height: 16px;
  }

  &:hover {
    color: $primary;
    border-color: $primary;
    background: $primary-light;
  }
}
</style>
