export const MANAGER_ROLES = ['dept_admin', 'super_admin'] as const

export type UserRole = 'student' | 'lecturer' | 'trainer' | 'dept_admin' | 'super_admin'

export function isManagerRole(role: string | null | undefined) {
  return !!role && (MANAGER_ROLES as readonly string[]).includes(role)
}

export function publicUser(user: {
  id: number
  name: string
  username: string
  avatarColor: string
  role: string
  department?: { name: string } | null
}) {
  return {
    id: user.id,
    name: user.name,
    username: user.username,
    avatarColor: user.avatarColor,
    role: user.role as UserRole,
    canManage: isManagerRole(user.role),
    departmentName: user.department?.name || '',
  }
}
