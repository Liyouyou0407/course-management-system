export type CourseTag = 'hot' | 'live' | 'upcoming'

export type CourseLearnStatus = 'enrolling' | 'learning' | 'completed' | 'not_started'

export type MyCourseFilter = 'all' | 'in_progress' | 'not_started' | 'completed'

export type CourseCategory = 'all' | 'hot' | 'upcoming' | 'new' | 'favorite'

export interface Course {
  id: number
  title: string
  coverGradient: string
  lecturerName: string
  plannedDate: string
  weekday: string
  startTime: string
  endTime: string
  location: string
  departmentName: string
  studentCount: number
  isHot: boolean
  isNew: boolean
  isLive: boolean
  isFavorited: boolean
  isEnrolled: boolean
  statusLabel: CourseLearnStatus
  ratingAvg: number | null
  ratingCount: number
  canEvaluate?: boolean
  myRating?: number | null
}

export interface MyCourse {
  id: number
  courseId: number
  courseTitle: string
  coverGradient: string
  lecturerName: string
  plannedDate: string
  weekday: string
  startTime: string
  endTime: string
  location: string
  departmentName: string
  tag: 'live' | 'upcoming'
  learnStatus: 'in_progress' | 'not_started' | 'completed'
  progressPercent: number
  lastStudyAt: string | null
  startDate: string | null
  completedAt: string | null
  score: number | null
  canEvaluate?: boolean
  myRating?: number | null
  ratingAvg?: number | null
  ratingCount?: number
}

export interface HomeStats {
  totalCourses: number
  completed: number
  inProgress: number
  totalHours: number
}

export interface CategoryTab {
  key: string
  label: string
  count: number
}

export type PortalMode = 'student' | 'admin'

export type UserRole = 'student' | 'lecturer' | 'trainer' | 'dept_admin' | 'super_admin'

export interface UserInfo {
  id: number
  name: string
  username: string
  avatarColor: string
  role?: UserRole | string
  canManage?: boolean
  departmentName?: string
}

export interface AdminStats {
  totalCourses: number
  totalStudents: number
  inProgressCourses: number
  completionRate: number
  published: number
  draft: number
  archived: number
  enrollments: number
  evaluations: number
  deltas: {
    totalCourses: number
    totalStudents: number
    inProgressCourses: number
    completionRate: number
  }
}

export interface AdminTrendPoint {
  label: string
  value: number
}

export interface AdminActivity {
  id: string
  type: string
  text: string
  timeLabel: string
}

export interface AdminHotCourse {
  id: number
  title: string
  studentCount: number
}

export interface AdminCourseRow {
  id: number
  title: string
  lecturerName: string
  departmentId?: number | null
  departmentName: string
  plannedDate: string
  weekday: string
  startTime: string
  endTime: string
  location?: string
  status: string
  isHot: boolean
  isNew: boolean
  studentCount: number
  ratingAvg: number | null
  ratingCount: number
}

export interface AdminCoursePayload {
  title: string
  lecturerName: string
  departmentId?: number | null
  plannedDate: string
  weekday: string
  startTime: string
  endTime: string
  location?: string
  isHot?: boolean
  isNew?: boolean
  status?: 'published' | 'draft' | 'archived'
}

export interface AdminStudentRow {
  id: number
  name: string
  username: string
  avatarColor: string
  departmentName: string
  enrolledCount: number
  progressPercent: number
  completedCount: number
  totalHours: number
}

export interface AdminStudentDetail {
  id: number
  name: string
  username: string
  avatarColor: string
  departmentName: string
  courses: Array<{
    courseId: number
    title: string
    progressPercent: number
    lastStudyAt: string | null
    completedAt: string | null
  }>
}

export interface AdminDepartment {
  id: number
  name: string
}

export interface PageResult<T> {
  list: T[]
  total: number
  page: number
  page_size: number
  total_pages: number
  counts?: Record<string, number>
}
