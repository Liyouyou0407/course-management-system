import { Router } from 'express'
import { z } from 'zod'
import { prisma } from '../lib/prisma'
import { getRatingMap, getStudentCountMap } from '../lib/courseMap'
import { fail, ok } from '../lib/response'
import { authRequired, type AuthRequest } from '../middleware/auth'
import { managerRequired } from '../middleware/manager'

const router = Router()

router.use(authRequired, managerRequired)

const COVER_GRADIENTS = [
  'linear-gradient(135deg, #3a86e0 0%, #7eb6ff 100%)',
  'linear-gradient(135deg, #0f438a 0%, #1769e0 100%)',
  'linear-gradient(135deg, #082a5e 0%, #1258c4 100%)',
  'linear-gradient(135deg, #061f45 0%, #0d4a9e 100%)',
  'linear-gradient(135deg, #1a5fb4 0%, #4a90e2 100%)',
  'linear-gradient(135deg, #0a3a7a 0%, #1769e0 100%)',
]

const courseBodySchema = z.object({
  title: z.string().min(1),
  lecturerName: z.string().min(1),
  departmentId: z.number().int().nullable().optional(),
  plannedDate: z.string().min(1),
  weekday: z.string().min(1),
  startTime: z.string().min(1),
  endTime: z.string().min(1),
  location: z.string().optional(),
  isHot: z.boolean().optional(),
  isNew: z.boolean().optional(),
  status: z.enum(['published', 'draft', 'archived']).optional(),
})

function monthStart(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1)
}

function addMonths(d: Date, n: number) {
  return new Date(d.getFullYear(), d.getMonth() + n, 1)
}

function formatMonthLabel(d: Date) {
  return `${d.getMonth() + 1}月`
}

function formatActivityTime(d: Date) {
  const now = new Date()
  const sameDay =
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate()
  const hh = String(d.getHours()).padStart(2, '0')
  const mm = String(d.getMinutes()).padStart(2, '0')
  if (sameDay) return `今天 ${hh}:${mm}`
  const yesterday = new Date(now)
  yesterday.setDate(now.getDate() - 1)
  const isYest =
    d.getFullYear() === yesterday.getFullYear() &&
    d.getMonth() === yesterday.getMonth() &&
    d.getDate() === yesterday.getDate()
  if (isYest) return `昨天 ${hh}:${mm}`
  return `${d.getMonth() + 1}-${String(d.getDate()).padStart(2, '0')} ${hh}:${mm}`
}

router.get('/departments', async (_req, res) => {
  const list = await prisma.department.findMany({
    orderBy: { sortOrder: 'asc' },
    select: { id: true, name: true },
  })
  return ok(res, list)
})

router.get('/stats', async (_req, res) => {
  const now = new Date()
  const thisMonth = monthStart(now)
  const lastMonth = addMonths(thisMonth, -1)

  const [
    totalCourses,
    published,
    draft,
    archived,
    totalStudents,
    inProgressCourses,
    completedProgress,
    allProgress,
    coursesThisMonth,
    coursesLastMonth,
    studentsThisMonth,
    studentsLastMonth,
    enrollments,
    evaluations,
  ] = await Promise.all([
    prisma.course.count(),
    prisma.course.count({ where: { status: 'published' } }),
    prisma.course.count({ where: { status: 'draft' } }),
    prisma.course.count({ where: { status: 'archived' } }),
    prisma.user.count({
      where: {
        OR: [{ role: 'student' }, { enrollments: { some: {} } }],
      },
    }),
    prisma.course.count({
      where: {
        status: 'published',
        learningProgress: { some: { progressPercent: { gt: 0, lt: 100 } } },
      },
    }),
    prisma.learningProgress.count({ where: { progressPercent: { gte: 100 } } }),
    prisma.learningProgress.count({ where: { progressPercent: { gt: 0 } } }),
    prisma.course.count({ where: { createdAt: { gte: thisMonth } } }),
    prisma.course.count({
      where: { createdAt: { gte: lastMonth, lt: thisMonth } },
    }),
    prisma.user.count({
      where: {
        createdAt: { gte: thisMonth },
        OR: [{ role: 'student' }, { enrollments: { some: {} } }],
      },
    }),
    prisma.user.count({
      where: {
        createdAt: { gte: lastMonth, lt: thisMonth },
        OR: [{ role: 'student' }, { enrollments: { some: {} } }],
      },
    }),
    prisma.enrollment.count({ where: { status: 'approved' } }),
    prisma.evaluation.count(),
  ])

  const completionRate =
    allProgress === 0 ? 0 : Math.round((completedProgress / allProgress) * 100)

  // 进行中环比：本月新增「进行中进度」条数近似
  const [inProgThis, inProgLast, doneThis, doneLast] = await Promise.all([
    prisma.learningProgress.count({
      where: {
        progressPercent: { gt: 0, lt: 100 },
        updatedAt: { gte: thisMonth },
      },
    }),
    prisma.learningProgress.count({
      where: {
        progressPercent: { gt: 0, lt: 100 },
        updatedAt: { gte: lastMonth, lt: thisMonth },
      },
    }),
    prisma.learningProgress.count({
      where: { completedAt: { gte: thisMonth } },
    }),
    prisma.learningProgress.count({
      where: { completedAt: { gte: lastMonth, lt: thisMonth } },
    }),
  ])

  const rateThis =
    inProgThis + doneThis === 0
      ? completionRate
      : Math.round((doneThis / (inProgThis + doneThis)) * 100)
  const rateLast =
    inProgLast + doneLast === 0
      ? 0
      : Math.round((doneLast / (inProgLast + doneLast)) * 100)

  return ok(res, {
    totalCourses,
    totalStudents,
    inProgressCourses,
    completionRate,
    published,
    draft,
    archived,
    enrollments,
    evaluations,
    deltas: {
      totalCourses: coursesThisMonth - coursesLastMonth,
      totalStudents: studentsThisMonth - studentsLastMonth,
      inProgressCourses: inProgThis - inProgLast,
      completionRate: rateThis - rateLast,
    },
  })
})

router.get('/enrollment-trend', async (req, res) => {
  const months = Math.min(12, Math.max(3, Number(req.query.months) || 6))
  const now = new Date()
  const start = addMonths(monthStart(now), -(months - 1))

  const enrollments = await prisma.enrollment.findMany({
    where: { signedUpAt: { gte: start }, status: 'approved' },
    select: { signedUpAt: true },
  })

  const buckets: { key: string; label: string; count: number }[] = []
  for (let i = 0; i < months; i++) {
    const m = addMonths(start, i)
    const key = `${m.getFullYear()}-${m.getMonth()}`
    buckets.push({ key, label: formatMonthLabel(m), count: 0 })
  }
  const index = new Map(buckets.map((b, i) => [b.key, i]))
  for (const e of enrollments) {
    const d = e.signedUpAt
    const key = `${d.getFullYear()}-${d.getMonth()}`
    const idx = index.get(key)
    if (idx != null) buckets[idx].count += 1
  }

  return ok(res, {
    months,
    points: buckets.map((b) => ({ label: b.label, value: b.count })),
  })
})

router.get('/activities', async (req, res) => {
  const limit = Math.min(20, Math.max(1, Number(req.query.limit) || 8))

  const [enrolls, completes] = await Promise.all([
    prisma.enrollment.findMany({
      where: { status: 'approved' },
      orderBy: { signedUpAt: 'desc' },
      take: limit,
      include: {
        student: { select: { name: true } },
        course: { select: { title: true } },
      },
    }),
    prisma.learningProgress.findMany({
      where: { completedAt: { not: null } },
      orderBy: { completedAt: 'desc' },
      take: limit,
      include: {
        user: { select: { name: true } },
        course: { select: { title: true } },
      },
    }),
  ])

  type Act = { type: string; text: string; at: Date }
  const merged: Act[] = [
    ...enrolls.map((e) => ({
      type: 'enroll',
      text: `${e.student.name} 报名了《${e.course.title}》`,
      at: e.signedUpAt,
    })),
    ...completes.map((c) => ({
      type: 'complete',
      text: `${c.user.name} 完成了《${c.course.title}》`,
      at: c.completedAt!,
    })),
  ]
  merged.sort((a, b) => b.at.getTime() - a.at.getTime())

  return ok(
    res,
    merged.slice(0, limit).map((a, i) => ({
      id: `${a.type}-${i}-${a.at.getTime()}`,
      type: a.type,
      text: a.text,
      timeLabel: formatActivityTime(a.at),
    })),
  )
})

router.get('/hot-courses', async (req, res) => {
  const limit = Math.min(10, Math.max(1, Number(req.query.limit) || 5))
  const courses = await prisma.course.findMany({
    where: { status: 'published' },
    select: { id: true, title: true },
  })
  const ids = courses.map((c) => c.id)
  const counts = await getStudentCountMap(ids)
  const ranked = courses
    .map((c) => ({
      id: c.id,
      title: c.title,
      studentCount: counts.get(c.id) || 0,
    }))
    .sort((a, b) => b.studentCount - a.studentCount)
    .slice(0, limit)

  return ok(res, ranked)
})

router.get('/courses', async (req: AuthRequest, res) => {
  const page = Math.max(1, Number(req.query.page) || 1)
  const pageSize = Math.min(50, Math.max(1, Number(req.query.page_size) || 10))
  const keyword = String(req.query.keyword || '').trim()

  const where: Record<string, unknown> = {}
  if (keyword) {
    where.OR = [
      { title: { contains: keyword } },
      { lecturerName: { contains: keyword } },
    ]
  }

  const [total, rows] = await Promise.all([
    prisma.course.count({ where }),
    prisma.course.findMany({
      where,
      include: { department: true },
      orderBy: { id: 'asc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
  ])

  const ids = rows.map((c) => c.id)
  const [ratings, counts] = await Promise.all([getRatingMap(ids), getStudentCountMap(ids)])

  const list = rows.map((course) => {
    const rating = ratings.get(course.id)!
    return {
      id: course.id,
      title: course.title,
      lecturerName: course.lecturerName,
      departmentId: course.departmentId,
      departmentName: course.department?.name || '',
      plannedDate: course.plannedDate,
      weekday: course.weekday,
      startTime: course.startTime,
      endTime: course.endTime,
      location: course.location,
      status: course.status,
      isHot: course.isHot,
      isNew: course.isNew,
      studentCount: counts.get(course.id) || 0,
      ratingAvg: rating.avg,
      ratingCount: rating.count,
    }
  })

  return ok(res, {
    list,
    total,
    page,
    page_size: pageSize,
    total_pages: Math.max(1, Math.ceil(total / pageSize)),
  })
})

router.post('/courses', async (req, res) => {
  const parsed = courseBodySchema.safeParse(req.body)
  if (!parsed.success) return fail(res, '请填写完整的课程信息')

  const data = parsed.data
  const count = await prisma.course.count()
  const created = await prisma.course.create({
    data: {
      title: data.title,
      lecturerName: data.lecturerName,
      departmentId: data.departmentId ?? null,
      plannedDate: data.plannedDate,
      weekday: data.weekday,
      startTime: data.startTime,
      endTime: data.endTime,
      location: data.location || '腾讯会议',
      isHot: data.isHot ?? false,
      isNew: data.isNew ?? true,
      status: data.status || 'draft',
      coverGradient: COVER_GRADIENTS[count % COVER_GRADIENTS.length],
      isLive: true,
    },
  })

  return ok(res, { id: created.id, status: created.status })
})

router.patch('/courses/:id', async (req, res) => {
  const id = Number(req.params.id)
  if (!id) return fail(res, '课程 ID 无效')

  const parsed = courseBodySchema.partial().safeParse(req.body)
  if (!parsed.success) return fail(res, '课程信息无效')

  const exists = await prisma.course.findUnique({ where: { id } })
  if (!exists) return fail(res, '课程不存在', 404, 404)

  const data = parsed.data
  const updated = await prisma.course.update({
    where: { id },
    data: {
      ...(data.title != null ? { title: data.title } : {}),
      ...(data.lecturerName != null ? { lecturerName: data.lecturerName } : {}),
      ...(data.departmentId !== undefined ? { departmentId: data.departmentId } : {}),
      ...(data.plannedDate != null ? { plannedDate: data.plannedDate } : {}),
      ...(data.weekday != null ? { weekday: data.weekday } : {}),
      ...(data.startTime != null ? { startTime: data.startTime } : {}),
      ...(data.endTime != null ? { endTime: data.endTime } : {}),
      ...(data.location != null ? { location: data.location } : {}),
      ...(data.isHot != null ? { isHot: data.isHot } : {}),
      ...(data.isNew != null ? { isNew: data.isNew } : {}),
      ...(data.status != null ? { status: data.status } : {}),
    },
  })

  return ok(res, { id: updated.id, status: updated.status })
})

router.patch('/courses/:id/status', async (req: AuthRequest, res) => {
  const id = Number(req.params.id)
  if (!id) return fail(res, '课程 ID 无效')

  const schema = z.object({
    status: z.enum(['published', 'draft', 'archived']),
  })
  const parsed = schema.safeParse(req.body)
  if (!parsed.success) return fail(res, '状态无效，仅支持 published / draft / archived')

  const course = await prisma.course.findUnique({ where: { id } })
  if (!course) return fail(res, '课程不存在', 404, 404)

  const updated = await prisma.course.update({
    where: { id },
    data: { status: parsed.data.status },
  })

  return ok(res, {
    id: updated.id,
    status: updated.status,
  })
})

router.get('/students', async (req, res) => {
  const page = Math.max(1, Number(req.query.page) || 1)
  const pageSize = Math.min(50, Math.max(1, Number(req.query.page_size) || 10))
  const keyword = String(req.query.keyword || '').trim()
  const departmentId = Number(req.query.department_id) || 0

  const where: Record<string, unknown> = {
    OR: [{ role: 'student' }, { enrollments: { some: {} } }],
  }
  const and: Record<string, unknown>[] = []
  if (keyword) {
    and.push({
      OR: [
        { name: { contains: keyword } },
        { username: { contains: keyword } },
        { department: { name: { contains: keyword } } },
      ],
    })
  }
  if (departmentId) {
    and.push({ departmentId })
  }
  if (and.length) where.AND = and

  const [total, users] = await Promise.all([
    prisma.user.count({ where }),
    prisma.user.findMany({
      where,
      include: {
        department: true,
        enrollments: { where: { status: 'approved' }, select: { courseId: true } },
        learningProgress: true,
      },
      orderBy: { id: 'asc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
  ])

  const list = users.map((u) => {
    const progresses = u.learningProgress
    const enrolled = u.enrollments.length
    const completed = progresses.filter((p) => p.progressPercent >= 100).length
    const avgProgress =
      progresses.length === 0
        ? 0
        : Math.round(
            progresses.reduce((s, p) => s + p.progressPercent, 0) / progresses.length,
          )
    const totalHours = Math.round(
      progresses.reduce((s, p) => s + p.watchedMinutes, 0) / 60,
    )
    return {
      id: u.id,
      name: u.name,
      username: u.username,
      avatarColor: u.avatarColor,
      departmentName: u.department?.name || '—',
      enrolledCount: enrolled,
      progressPercent: avgProgress,
      completedCount: completed,
      totalHours,
    }
  })

  return ok(res, {
    list,
    total,
    page,
    page_size: pageSize,
    total_pages: Math.max(1, Math.ceil(total / pageSize)),
  })
})

router.get('/students/:id', async (req, res) => {
  const id = Number(req.params.id)
  if (!id) return fail(res, '学员 ID 无效')

  const user = await prisma.user.findUnique({
    where: { id },
    include: {
      department: true,
      enrollments: {
        where: { status: 'approved' },
        include: { course: true },
        orderBy: { signedUpAt: 'desc' },
      },
      learningProgress: true,
    },
  })
  if (!user) return fail(res, '学员不存在', 404, 404)

  const progressMap = new Map(user.learningProgress.map((p) => [p.courseId, p]))
  const courses = user.enrollments.map((e) => {
    const p = progressMap.get(e.courseId)
    return {
      courseId: e.courseId,
      title: e.course.title,
      progressPercent: p?.progressPercent ?? 0,
      lastStudyAt: p?.lastStudyAt ? p.lastStudyAt.toISOString().slice(0, 10) : null,
      completedAt: p?.completedAt ? p.completedAt.toISOString().slice(0, 10) : null,
    }
  })

  return ok(res, {
    id: user.id,
    name: user.name,
    username: user.username,
    avatarColor: user.avatarColor,
    departmentName: user.department?.name || '—',
    courses,
  })
})

export default router
