# Design Tokens

> 来源：`course-client/src/styles/variables.scss`

## 颜色

| Token | 值 | 用途 |
|-------|-----|------|
| primary | `#1769e0` | 主按钮、链接、选中态 |
| primary-light | `#eaf3ff` | 浅底标签、软按钮 |
| primary-hover | `#1258c4` | 主色悬停 |
| deep（封面） | `#082a5e` → `#1258c4` | 热门封面档 |
| navy（封面） | `#061f45` → `#0d4a9e` | 深蓝封面档 |
| sky（封面） | `#3a86e0` → `#7eb6ff` | 浅封面档 / 最新 |
| text-title / body | `#10243f` | 标题与正文 |
| text-secondary | `#708096` | 次要文案 |
| text-muted | `#8896a7` | 弱化信息 |
| border | `#e1e9f2` | 描边 |
| bg-page | `#f5f8fc` | 页面底 |
| warning（评分） | `#e9992c` | ★ 均分语义色 |
| success | `#22c55e` | 成功/上涨 delta |

## 圆角与阴影

| Token | 值 |
|-------|-----|
| radius-card | 15px |
| radius-btn | 8px |
| radius-pill | 20px |
| shadow-card | none |
| shadow-hover | `0 18px 60px rgba(29, 71, 126, 0.1)` |

## 字号阶梯

| Token | 值 | 场景 |
|-------|-----|------|
| font-size-base | 14px | 正文、表格、按钮 |
| font-size-title | 18px | 区块标题 |
| font-size-card-title | 17px | 课程卡标题 |
| font-size-metric | 26px | 统计/指标大数字 |
| 辅助 | 11–13px | 标签、meta、描述 |

## 字体栈

`-apple-system, BlinkMacSystemFont, 'PingFang SC', 'Microsoft YaHei', 'Segoe UI', sans-serif`

学员端与管理端共用同一字体栈与基准字号。

## 布局

| Token | 值 |
|-------|-----|
| page-width | 1200px |
| nav-height | 64px |

## 封面主题类

`sky` | `blue` | `deep` | `navy` — 仅蓝色相深浅差异，见 `styles/course-cover.scss`。
