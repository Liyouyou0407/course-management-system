<template>
  <div class="metric">
    <div class="metric__icon" :class="tone">
      <slot name="icon" />
    </div>
    <div class="metric__body">
      <div class="metric__row">
        <span class="metric__value">{{ value }}</span>
        <span v-if="deltaText" class="metric__delta" :class="{ down: delta < 0 }">{{ deltaText }}</span>
      </div>
      <p class="metric__label">{{ label }}</p>
      <p class="metric__desc">{{ desc }}</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    value: string | number
    label: string
    desc: string
    delta?: number
    deltaSuffix?: string
    tone?: 'blue' | 'green' | 'purple' | 'orange'
  }>(),
  { tone: 'blue', delta: 0, deltaSuffix: '' },
)

const deltaText = computed(() => {
  if (props.delta === 0) return ''
  const sign = props.delta > 0 ? '+' : ''
  return `${sign}${props.delta}${props.deltaSuffix} 较上月`
})
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.metric {
  @include card;
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 18px 20px;
  background: #fff;
}

.metric__icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;

  :deep(svg) {
    width: 24px;
    height: 24px;
  }

  &.blue {
    background: #e8efff;
    color: $primary;
  }

  &.green {
    background: #e8faf0;
    color: $success;
  }

  &.purple {
    background: #f3e8ff;
    color: #9333ea;
  }

  &.orange {
    background: #fff7ed;
    color: #ea580c;
  }
}

.metric__body {
  min-width: 0;
}

.metric__row {
  display: flex;
  align-items: baseline;
  gap: 8px;
}

.metric__value {
  font-size: 28px;
  font-weight: 700;
  color: $text-title;
  line-height: 1.1;
}

.metric__delta {
  font-size: 12px;
  color: $success;
  white-space: nowrap;

  &.down {
    color: #ef4444;
  }
}

.metric__label {
  margin-top: 4px;
  font-size: 14px;
  font-weight: 500;
  color: $text-body;
}

.metric__desc {
  margin-top: 2px;
  font-size: 12px;
  color: $text-muted;
}
</style>
