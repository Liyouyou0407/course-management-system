<template>
  <div class="students page-container">
    <div class="students__toolbar">
      <SearchBar
        v-model="keyword"
        placeholder="搜索学员姓名/部门"
        @filter="showFilter = !showFilter"
      />
    </div>
    <div v-if="showFilter" class="students__filter">
      <label>
        <span>所属部门</span>
        <select v-model.number="departmentId" @change="reload">
          <option :value="0">全部部门</option>
          <option v-for="d in departments" :key="d.id" :value="d.id">{{ d.name }}</option>
        </select>
      </label>
      <button type="button" class="btn btn-outline" @click="clearFilter">重置</button>
    </div>

    <p v-if="error" class="students__error">{{ error }}</p>
    <EmptyState v-else-if="!loading && list.length === 0" text="没有找到相关学员" />

    <div v-else class="students__table-wrap">
      <table class="students__table">
        <thead>
          <tr>
            <th>学员姓名</th>
            <th>所属部门</th>
            <th>已学课程</th>
            <th>学习进度</th>
            <th>已完成</th>
            <th>累计学时</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in list" :key="row.id">
            <td>
              <div class="user-cell">
                <span class="avatar" :style="{ background: row.avatarColor }">{{ row.name.slice(0, 1) }}</span>
                <strong>{{ row.name }}</strong>
              </div>
            </td>
            <td>{{ row.departmentName }}</td>
            <td>{{ row.enrolledCount }} 门</td>
            <td class="progress-cell">
              <ProgressBar :percent="row.progressPercent" />
              <span>{{ row.progressPercent }}%</span>
            </td>
            <td>{{ row.completedCount }} 门</td>
            <td>{{ row.totalHours }} 小时</td>
            <td>
              <button type="button" class="link" @click="openDetail(row.id)">查看详情</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <Pagination
      v-model:page="page"
      v-model:page-size="pageSize"
      :total="total"
      :page-sizes="[8, 10, 20]"
    />

    <div v-if="detailOpen" class="drawer-mask" @click.self="detailOpen = false">
      <aside class="drawer">
        <div class="drawer__head">
          <h3>学员详情</h3>
          <button type="button" @click="detailOpen = false">×</button>
        </div>
        <p v-if="detailError" class="students__error">{{ detailError }}</p>
        <div v-else-if="detail" class="drawer__body">
          <div class="drawer__user">
            <span class="avatar lg" :style="{ background: detail.avatarColor }">
              {{ detail.name.slice(0, 1) }}
            </span>
            <div>
              <strong>{{ detail.name }}</strong>
              <p>{{ detail.departmentName }} · {{ detail.username }}</p>
            </div>
          </div>
          <h4>报名课程</h4>
          <ul class="course-list">
            <li v-for="c in detail.courses" :key="c.courseId">
              <div>
                <strong>{{ c.title }}</strong>
                <p v-if="c.lastStudyAt">上次学习：{{ c.lastStudyAt }}</p>
              </div>
              <div class="course-list__right">
                <ProgressBar :percent="c.progressPercent" />
                <span>{{ c.progressPercent }}%</span>
              </div>
            </li>
            <li v-if="detail.courses.length === 0" class="empty">暂无报名课程</li>
          </ul>
        </div>
      </aside>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'
import SearchBar from '@/components/common/SearchBar.vue'
import Pagination from '@/components/common/Pagination.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import ProgressBar from '@/components/common/ProgressBar.vue'
import {
  fetchAdminDepartments,
  fetchAdminStudentDetail,
  fetchAdminStudents,
} from '@/api/admin'
import type { AdminDepartment, AdminStudentDetail, AdminStudentRow } from '@/types/course'

const page = ref(1)
const pageSize = ref(10)
const total = ref(0)
const keyword = ref('')
const departmentId = ref(0)
const showFilter = ref(false)
const departments = ref<AdminDepartment[]>([])
const loading = ref(false)
const error = ref('')
const list = ref<AdminStudentRow[]>([])

const detailOpen = ref(false)
const detail = ref<AdminStudentDetail | null>(null)
const detailError = ref('')

async function load() {
  loading.value = true
  error.value = ''
  try {
    const data = await fetchAdminStudents({
      page: page.value,
      page_size: pageSize.value,
      keyword: keyword.value.trim(),
      department_id: departmentId.value || undefined,
    })
    list.value = data.list
    total.value = data.total
  } catch (e) {
    error.value = e instanceof Error ? e.message : '加载失败'
  } finally {
    loading.value = false
  }
}

function reload() {
  page.value = 1
  load()
}

function clearFilter() {
  departmentId.value = 0
  reload()
}

onMounted(async () => {
  try {
    departments.value = await fetchAdminDepartments()
  } catch {
    /* ignore */
  }
})

async function openDetail(id: number) {
  detailOpen.value = true
  detail.value = null
  detailError.value = ''
  try {
    detail.value = await fetchAdminStudentDetail(id)
  } catch (e) {
    detailError.value = e instanceof Error ? e.message : '加载详情失败'
  }
}

let keywordTimer: number | undefined
watch(keyword, () => {
  window.clearTimeout(keywordTimer)
  keywordTimer = window.setTimeout(() => reload(), 300)
})

watch([page, pageSize], () => load())
load()
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.students {
  display: flex;
  flex-direction: column;
}

.students__toolbar {
  margin-bottom: 14px;

  :deep(.search-bar) {
    width: 100%;
  }
}

.students__filter {
  display: flex;
  align-items: flex-end;
  gap: 12px;
  margin: -4px 0 14px;
  padding: 12px 14px;
  background: #fff;
  border: 1px solid $border;
  border-radius: 10px;

  label {
    display: flex;
    flex-direction: column;
    gap: 6px;
    font-size: 13px;
    color: $text-secondary;
  }

  select {
    height: 36px;
    min-width: 200px;
    border: 1px solid $border;
    border-radius: 8px;
    padding: 0 10px;
    font-size: 14px;
    color: $text-title;
    background: #fff;

    &:focus {
      outline: none;
      border-color: $primary;
    }
  }

  .btn {
    height: 36px;
    padding: 0 14px;
  }
}

.students__error {
  color: #ef4444;
  font-size: 13px;
  margin-bottom: 12px;
}

.students__table-wrap {
  @include card;
  background: #fff;
  overflow: auto;
  margin-bottom: 16px;
  flex: 1;
}

.students__table {
  width: 100%;
  border-collapse: collapse;
  min-width: 900px;

  th,
  td {
    padding: 14px 16px;
    text-align: left;
    border-bottom: 1px solid #f0f2f7;
    font-size: 14px;
    color: $text-secondary;
    vertical-align: middle;
  }

  th {
    color: $text-muted;
    font-weight: 500;
    font-size: 13px;
    background: #fafbff;
  }
}

.user-cell {
  display: flex;
  align-items: center;
  gap: 10px;

  strong {
    color: $text-title;
    font-size: 14px;
  }
}

.avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  color: #fff;
  font-size: 13px;
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  justify-content: center;

  &.lg {
    width: 44px;
    height: 44px;
    font-size: 16px;
  }
}

.progress-cell {
  min-width: 160px;
  display: flex;
  align-items: center;
  gap: 8px;

  span {
    flex-shrink: 0;
    width: 36px;
    color: $primary;
    font-weight: 500;
  }
}

.link {
  border: none;
  background: transparent;
  color: $primary;
  font-size: 13px;
  cursor: pointer;

  &:hover {
    text-decoration: underline;
  }
}

.drawer-mask {
  position: fixed;
  inset: 0;
  z-index: 200;
  background: rgba(15, 23, 42, 0.35);
  display: flex;
  justify-content: flex-end;
}

.drawer {
  width: min(420px, 100%);
  height: 100%;
  background: #fff;
  box-shadow: -8px 0 32px rgba(15, 23, 42, 0.12);
  display: flex;
  flex-direction: column;
}

.drawer__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 18px 20px;
  border-bottom: 1px solid $border;

  h3 {
    font-size: 17px;
    color: $text-title;
  }

  button {
    border: none;
    background: transparent;
    font-size: 22px;
    color: $text-muted;
    cursor: pointer;
  }
}

.drawer__body {
  padding: 20px;
  overflow: auto;
  flex: 1;

  h4 {
    margin: 18px 0 12px;
    font-size: 14px;
    color: $text-secondary;
  }
}

.drawer__user {
  display: flex;
  align-items: center;
  gap: 12px;

  strong {
    display: block;
    font-size: 16px;
    color: $text-title;
  }

  p {
    margin-top: 4px;
    font-size: 13px;
    color: $text-muted;
  }
}

.course-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 12px;

  li {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    padding: 12px;
    border-radius: 10px;
    background: #f8faff;
  }

  strong {
    display: block;
    font-size: 13px;
    color: $text-title;
    margin-bottom: 4px;
  }

  p {
    font-size: 12px;
    color: $text-muted;
  }

  &__right {
    width: 110px;
    display: flex;
    flex-direction: column;
    gap: 4px;
    align-items: flex-end;

    span {
      font-size: 12px;
      color: $primary;
    }
  }

  .empty {
    background: transparent;
    color: $text-muted;
    font-size: 13px;
  }
}
</style>
