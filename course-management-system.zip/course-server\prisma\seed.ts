import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

const gradients = [
  'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
  'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
  'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
  'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
  'linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%)',
  'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
  'linear-gradient(135deg, #89f7fe 0%, #66a6ff 100%)',
  'linear-gradient(135deg, #f6d365 0%, #fda085 100%)',
  'linear-gradient(135deg, #96fbc4 0%, #f9f586 100%)',
  'linear-gradient(135deg, #c471f5 0%, #fa71cd 100%)',
  'linear-gradient(135deg, #48c6ef 0%, #6f86d6 100%)',
]

async function addEval(
  courseId: number,
  studentId: number,
  scores: [number, number, number, number],
  feedback?: string,
) {
  const [a, b, c, d] = scores
  const avgScore = Math.round(((a + b + c + d) / 4) * 10) / 10
  await prisma.evaluation.create({
    data: {
      courseId,
      studentId,
      scoreExperience: a,
      scoreFluency: b,
      scorePracticality: c,
      scoreInspiration: d,
      avgScore,
      feedback,
    },
  })
}

async function main() {
  await prisma.evaluation.deleteMany()
  await prisma.learningProgress.deleteMany()
  await prisma.favorite.deleteMany()
  await prisma.enrollment.deleteMany()
  await prisma.notification.deleteMany()
  await prisma.course.deleteMany()
  await prisma.user.deleteMany()
  await prisma.department.deleteMany()

  const deptNames = [
    '广告策划部（本部）',
    '创新B中心',
    '创新C中心',
    '创意中心',
    '直播A中心',
    '营销A中心',
    '营销C中心',
    '营销D中心',
  ]
  const depts = []
  for (let i = 0; i < deptNames.length; i++) {
    depts.push(
      await prisma.department.create({
        data: { name: deptNames[i], sortOrder: i + 1 },
      }),
    )
  }

  const passwordHash = await bcrypt.hash('123456', 10)
  const student = await prisma.user.create({
    data: {
      username: 'lifengyun',
      passwordHash,
      name: '李凤芸',
      avatarColor: '#7c8cff',
      departmentId: depts[0].id,
      // 演示账号兼具管理端身份，可在学员端/管理端切换
      role: 'dept_admin',
    },
  })
  const other = await prisma.user.create({
    data: {
      username: 'demo',
      passwordHash,
      name: '演示学员',
      avatarColor: '#5b8cff',
      departmentId: depts[1].id,
      role: 'student',
    },
  })

  const courseDefs = [
    { title: '品牌传播策略与创意方法', lecturer: '李老师', dept: 0, date: '07-25', wd: '周五', start: '19:00', end: '21:00', hot: true, neu: false },
    { title: '活动策划全流程解析', lecturer: '陈老师', dept: 1, date: '07-18', wd: '周五', start: '19:00', end: '21:00', hot: false, neu: false },
    { title: '新媒体内容创作实战', lecturer: '张老师', dept: 3, date: '07-10', wd: '周四', start: '19:00', end: '21:00', hot: false, neu: true },
    { title: 'PPT演示设计提升课', lecturer: '刘老师', dept: 5, date: '07-05', wd: '周六', start: '19:00', end: '21:00', hot: false, neu: false },
    { title: '用户洞察与需求分析', lecturer: '王老师', dept: 0, date: '08-01', wd: '周五', start: '10:00', end: '11:30', hot: true, neu: true },
    { title: '数据驱动的营销策略', lecturer: '赵老师', dept: 6, date: '08-05', wd: '周二', start: '19:00', end: '21:00', hot: false, neu: true },
    { title: 'Python数据分析入门', lecturer: '周老师', dept: 2, date: '07-30', wd: '周三', start: '19:00', end: '21:00', hot: false, neu: true },
    { title: '设计思维与创新实践', lecturer: '孙老师', dept: 3, date: '08-08', wd: '周五', start: '14:00', end: '16:00', hot: true, neu: false },
    { title: '短视频脚本写作技巧', lecturer: '吴老师', dept: 4, date: '08-12', wd: '周二', start: '19:00', end: '20:30', hot: true, neu: true },
    { title: '客户沟通与提案技巧', lecturer: '郑老师', dept: 0, date: '08-15', wd: '周五', start: '19:00', end: '21:00', hot: false, neu: false },
    { title: '广告投放优化实战', lecturer: '钱老师', dept: 7, date: '08-18', wd: '周一', start: '19:00', end: '21:00', hot: false, neu: true },
    { title: '品牌视觉识别系统设计', lecturer: '冯老师', dept: 3, date: '08-20', wd: '周三', start: '10:00', end: '12:00', hot: false, neu: false },
  ]

  const courses = []
  for (let i = 0; i < courseDefs.length; i++) {
    const c = courseDefs[i]
    courses.push(
      await prisma.course.create({
        data: {
          title: c.title,
          coverGradient: gradients[i],
          departmentId: depts[c.dept].id,
          lecturerName: c.lecturer,
          plannedDate: c.date,
          weekday: c.wd,
          startTime: c.start,
          endTime: c.end,
          isHot: c.hot,
          isNew: c.neu,
          isLive: true,
          // 最后一门默认草稿，便于管理端演示上架
          status: i === courseDefs.length - 1 ? 'draft' : 'published',
        },
      }),
    )
  }

  const enrollPairs = [
    { idx: 0, progress: 60, last: '2026-07-18' },
    { idx: 1, progress: 40, last: '2026-07-15' },
    { idx: 2, progress: 20, last: '2026-07-12' },
    { idx: 3, progress: 0 },
    { idx: 4, progress: 100, last: '2026-06-25', completed: '2026-06-25' },
    { idx: 7, progress: 100, last: '2026-06-12', completed: '2026-06-12' },
  ]

  for (const p of enrollPairs) {
    const course = courses[p.idx]
    await prisma.enrollment.create({
      data: { courseId: course.id, studentId: student.id, status: 'approved' },
    })
    await prisma.learningProgress.create({
      data: {
        userId: student.id,
        courseId: course.id,
        progressPercent: p.progress,
        lastStudyAt: p.last ? new Date(p.last) : null,
        completedAt: p.completed ? new Date(p.completed) : null,
        watchedMinutes: p.progress * 2,
      },
    })
  }

  for (const idx of [0, 2, 4, 7, 9]) {
    await prisma.favorite.create({
      data: { userId: student.id, courseId: courses[idx].id },
    })
  }

  // other 学员的评价用于均分；课程4留给李凤芸去评价；课程7李凤芸已评
  await addEval(courses[0].id, other.id, [5, 4.5, 5, 4.5], '内容扎实')
  await addEval(courses[0].id, student.id, [4, 4, 4.5, 4], '不错')
  await addEval(courses[1].id, other.id, [4.5, 4.5, 5, 4])
  await addEval(courses[2].id, other.id, [5, 4, 4.5, 5])
  await addEval(courses[5].id, other.id, [4, 4.5, 4, 4])
  await addEval(courses[7].id, other.id, [5, 5, 4.5, 5])
  await addEval(courses[7].id, student.id, [4.5, 4.5, 5, 4], '很有启发')

  await prisma.notification.createMany({
    data: [
      {
        userId: student.id,
        title: '课程开课提醒',
        content: '《品牌传播策略与创意方法》将于 07-25 19:00 开课，请准时参加。',
        type: 'course_remind',
      },
      {
        userId: student.id,
        title: '报名成功',
        content: '你已成功报名《新媒体内容创作实战》。',
        type: 'signup',
      },
      {
        userId: student.id,
        title: '学习进度更新',
        content: '《活动策划全流程解析》学习进度已更新至 40%。',
        type: 'progress',
      },
    ],
  })

  console.log('Seed OK')
  console.log('账号: lifengyun / 123456（dept_admin，可切换管理端）')
  console.log('学员账号: demo / 123456（无管理端）')
  console.log('已完成可评价: 用户洞察与需求分析')
  console.log('已完成已评价: 设计思维与创新实践')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
