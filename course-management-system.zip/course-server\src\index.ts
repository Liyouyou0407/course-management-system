import cors from 'cors'
import express from 'express'
import authRoutes from './routes/auth'
import homeRoutes from './routes/home'
import courseRoutes from './routes/courses'
import enrollmentRoutes from './routes/enrollments'
import myCourseRoutes from './routes/myCourses'
import evaluationRoutes from './routes/evaluations'
import favoriteRoutes from './routes/favorites'
import notificationRoutes from './routes/notifications'
import adminRoutes from './routes/admin'

const app = express()
const port = Number(process.env.PORT) || 8080

app.use(
  cors({
    origin: ['http://localhost:5173', 'http://127.0.0.1:5173', 'http://localhost:3000', 'http://localhost:3004'],
    credentials: true,
  }),
)
app.use(express.json())

app.get('/api/v1/health', (_req, res) => {
  res.json({ code: 0, message: 'ok', data: { service: 'course-server' } })
})

app.use('/api/v1/auth', authRoutes)
app.use('/api/v1/home', homeRoutes)
app.use('/api/v1/courses', courseRoutes)
app.use('/api/v1/enrollments', enrollmentRoutes)
app.use('/api/v1/my-courses', myCourseRoutes)
app.use('/api/v1/evaluations', evaluationRoutes)
app.use('/api/v1/favorites', favoriteRoutes)
app.use('/api/v1/notifications', notificationRoutes)
app.use('/api/v1/admin', adminRoutes)

app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err)
  res.status(500).json({ code: 500, message: err.message || '服务器错误', data: null })
})

app.listen(port, () => {
  console.log(`course-server listening on http://localhost:${port}`)
})
