import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/LoginView.vue'),
      meta: { public: true },
    },
    {
      path: '/',
      component: () => import('@/views/MainLayout.vue'),
      children: [
        {
          path: '',
          name: 'home',
          component: () => import('@/views/HomeView.vue'),
        },
        {
          path: 'courses',
          name: 'courses',
          component: () => import('@/views/CourseCenterView.vue'),
        },
        {
          path: 'course/:id',
          name: 'course-detail',
          component: () => import('@/views/CourseDetailView.vue'),
        },
        {
          path: 'my-learning',
          name: 'my-learning',
          component: () => import('@/views/MyCoursesView.vue'),
        },
        {
          path: 'notifications',
          name: 'notifications',
          component: () => import('@/views/NotificationsView.vue'),
        },
        {
          path: 'profile',
          name: 'profile',
          component: () => import('@/views/ProfileView.vue'),
        },
      ],
    },
    {
      path: '/admin',
      component: () => import('@/views/AdminLayout.vue'),
      meta: { requiresManage: true },
      children: [
        {
          path: '',
          name: 'admin-home',
          component: () => import('@/views/AdminDashboardView.vue'),
        },
        {
          path: 'courses',
          name: 'admin-courses',
          component: () => import('@/views/AdminCoursesView.vue'),
        },
        {
          path: 'students',
          name: 'admin-students',
          component: () => import('@/views/AdminStudentsView.vue'),
        },
      ],
    },
  ],
  scrollBehavior() {
    return { top: 0 }
  },
})

function hasValidTokenFormat(token: string | null) {
  if (!token) return false
  return token.split('.').length === 3
}

router.beforeEach(async (to) => {
  const token = localStorage.getItem('token')
  const loggedIn = hasValidTokenFormat(token)

  if (token && !loggedIn) {
    localStorage.removeItem('token')
  }

  if (!to.meta.public && !loggedIn) {
    return { name: 'login', query: { redirect: to.fullPath } }
  }

  if (to.name === 'login' && loggedIn) {
    return { name: 'home' }
  }

  if (to.matched.some((r) => r.meta.requiresManage)) {
    const userStore = useUserStore()
    if (!userStore.user) {
      await userStore.fetchMe()
    }
    if (!userStore.canManage) {
      userStore.enterStudent()
      return { name: 'home' }
    }
    userStore.enterAdmin()
  }
})

export default router
