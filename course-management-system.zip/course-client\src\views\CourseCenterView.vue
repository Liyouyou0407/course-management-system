<template>
  <div class="center page-container">
    <SearchBar v-model="keyword" @filter="showFilter = !showFilter" />
    <div v-if="showFilter" class="center__filter">
      <label>
        <span>所属部门</span>
        <select v-model.number="departmentId" @change="reload">
          <option :value="0">全部部门</option>
          <option v-for="d in departments" :key="d.id" :value="d.id">{{ d.name }}</option>
        </select>
      </label>
      <button type="button" class="btn btn-outline" @click="clearFilter">重置</button>
    </div>

    <CategoryTabs v-model="category" :tabs="tabs" class="center__tabs" />

    <p v-if="error" class="center__error">{{ error }}</p>
    <EmptyState v-else-if="!loading && pagedList.length === 0" text="没有找到相关课程" />

    <div v-else class="center__grid">
      <CourseCard
        v-for="course in pagedList"
        :key="course.id"
        :course="course"
        variant="center"
        @click="goDetail(course.id)"
        @enroll="onEnroll"
        @toggle-favorite="onToggleFavorite"
      />
    </div>

    <Pagination
      v-model:page="page"
      v-model:page-size="pageSize"
      :total="total"
      :page-sizes="[8, 10, 12]"
    />
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import SearchBar from '@/components/common/SearchBar.vue'
import Pagination from '@/components/common/Pagination.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import CategoryTabs from '@/components/course/CategoryTabs.vue'
import CourseCard from '@/components/course/CourseCard.vue'
import { fetchCourses, fetchDepartments } from '@/api/courses'
import { enrollCourse } from '@/api/enrollments'
import { toggleFavorite } from '@/api/favorites'
import type { Course, CourseCategory } from '@/types/course'

const VALID_CATEGORIES: CourseCategory[] = ['all', 'new', 'hot', 'upcoming', 'favorite']

const router = useRouter()
const route = useRoute()
const keyword = ref('')
const category = ref<CourseCategory>(resolveCategory(route.query.category))
const page = ref(1)
const pageSize = ref(10)
const total = ref(0)
const showFilter = ref(false)
const departmentId = ref(0)
const departments = ref<{ id: number; name: string }[]>([])
const loading = ref(false)
const error = ref('')
const pagedList = ref<Course[]>([])
const counts = ref({ all: 0, new: 0, hot: 0, upcoming: 0, favorite: 0 })

const tabs = computed(() => [
  { key: 'all', label: '全部课程', count: counts.value.all },
  { key: 'new', label: '最新课程', count: counts.value.new },
  { key: 'hot', label: '热门课程', count: counts.value.hot },
  { key: 'upcoming', label: '即将开课', count: counts.value.upcoming },
  { key: 'favorite', label: '课程收藏', count: counts.value.favorite },
])

async function load() {
  loading.value = true
  error.value = ''
  try {
    const data = await fetchCourses({
      page: page.value,
      page_size: pageSize.value,
      keyword: keyword.value.trim(),
      category: category.value,
      department_id: departmentId.value || undefined,
    })
    pagedList.value = data.list
    total.value = data.total
    if (data.counts) {
      counts.value = {
        all: data.counts.all || 0,
        new: data.counts.new || 0,
        hot: data.counts.hot || 0,
        upcoming: data.counts.upcoming || 0,
        favorite: data.counts.favorite || 0,
      }
    }
  } catch (e) {
    error.value = e instanceof Error ? e.message : '加载失败'
  } finally {
    loading.value = false
  }
}

function reload() {
  if (page.value !== 1) page.value = 1
  else load()
}

function clearFilter() {
  departmentId.value = 0
  reload()
}

watch(
  () => route.query.category,
  (value) => {
    if (route.name !== 'courses') return
    const next = resolveCategory(value)
    if (category.value !== next) category.value = next
  },
)

watch(category, (value) => {
  if (route.name !== 'courses') return
  const current = resolveCategory(route.query.category)
  if (current !== value) {
    const nextQuery = { ...route.query }
    if (value === 'all') delete nextQuery.category
    else nextQuery.category = value
    router.replace({ path: '/courses', query: nextQuery })
  }
  reload()
})

watch([page, pageSize], () => {
  if (route.name !== 'courses') return
  load()
})

let keywordTimer: number | undefined
watch(keyword, () => {
  window.clearTimeout(keywordTimer)
  keywordTimer = window.setTimeout(() => {
    if (route.name !== 'courses') return
    reload()
  }, 300)
})

onMounted(async () => {
  try {
    departments.value = await fetchDepartments()
  } catch {
    /* ignore */
  }
  load()
})

function resolveCategory(raw: unknown): CourseCategory {
  const value = Array.isArray(raw) ? raw[0] : raw
  if (typeof value === 'string' && VALID_CATEGORIES.includes(value as CourseCategory)) {
    return value as CourseCategory
  }
  return 'all'
}

function goDetail(id: number) {
  router.push({ name: 'course-detail', params: { id: String(id) } })
}

async function onEnroll(course: Course) {
  if (course.isEnrolled) return
  try {
    await enrollCourse(course.id)
    course.isEnrolled = true
    course.statusLabel = 'learning'
    course.studentCount += 1
  } catch (e) {
    error.value = e instanceof Error ? e.message : '报名失败'
  }
}

async function onToggleFavorite(course: Course) {
  const prev = course.isFavorited
  try {
    const res = await toggleFavorite(course.id, prev)
    course.isFavorited = res.favorited
    if (prev && !res.favorited) {
      counts.value.favorite = Math.max(0, counts.value.favorite - 1)
      if (category.value === 'favorite') {
        pagedList.value = pagedList.value.filter((c) => c.id !== course.id)
        total.value = Math.max(0, total.value - 1)
      }
    } else if (!prev && res.favorited) {
      counts.value.favorite += 1
    }
  } catch (e) {
    error.value = e instanceof Error ? e.message : '收藏操作失败'
  }
}
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.center {
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.center__tabs {
  margin-top: 4px;
}

.center__filter {
  display: flex;
  align-items: flex-end;
  gap: 12px;
  margin-top: -6px;
  padding: 12px 14px;
  background: #fff;
  border: 1px solid $border;
  border-radius: 10px;

  label {
    display: flex;
    flex-direction: column;
    gap: 6px;
    font-size: 13px;
    color: $text-secondary;
  }

  select {
    height: 36px;
    min-width: 200px;
    border: 1px solid $border;
    border-radius: 8px;
    padding: 0 10px;
    font-size: 14px;
    color: $text-title;
    background: #fff;

    &:focus {
      outline: none;
      border-color: $primary;
    }
  }

  .btn {
    height: 36px;
    padding: 0 14px;
  }
}

.center__error {
  font-size: 12px;
  margin-top: -8px;
  color: #ef4444;
}

.center__grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;

  @media (max-width: 1024px) {
    grid-template-columns: repeat(2, 1fr);
  }

  @media (max-width: 767px) {
    grid-template-columns: 1fr;
  }
}
</style>
