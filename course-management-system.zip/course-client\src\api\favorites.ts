import { request } from './request'

export function addFavorite(courseId: number) {
  return request<{ course_id: number; favorited: boolean }>(`/favorites/${courseId}`, {
    method: 'POST',
  })
}

export function removeFavorite(courseId: number) {
  return request<{ course_id: number; favorited: boolean }>(`/favorites/${courseId}`, {
    method: 'DELETE',
  })
}

export async function toggleFavorite(courseId: number, currentlyFavorited: boolean) {
  if (currentlyFavorited) return removeFavorite(courseId)
  return addFavorite(courseId)
}
