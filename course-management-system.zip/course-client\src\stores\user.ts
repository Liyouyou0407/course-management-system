import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { loginApi, meApi } from '@/api/auth'
import type { PortalMode, UserInfo } from '@/types/course'

const PORTAL_KEY = 'portalMode'

function readPortalMode(): PortalMode {
  return localStorage.getItem(PORTAL_KEY) === 'admin' ? 'admin' : 'student'
}

export const useUserStore = defineStore('user', () => {
  const user = ref<UserInfo | null>(null)
  const portalMode = ref<PortalMode>(readPortalMode())

  const isLoggedIn = computed(() => !!localStorage.getItem('token'))
  const canManage = computed(() => !!user.value?.canManage)

  async function login(username: string, password: string) {
    const data = await loginApi(username, password)
    localStorage.setItem('token', data.token)
    user.value = data.user
    if (!data.user.canManage) {
      portalMode.value = 'student'
      localStorage.setItem(PORTAL_KEY, 'student')
    }
  }

  async function fetchMe() {
    if (!localStorage.getItem('token')) {
      user.value = null
      return
    }
    try {
      user.value = await meApi()
      if (!user.value.canManage && portalMode.value === 'admin') {
        portalMode.value = 'student'
        localStorage.setItem(PORTAL_KEY, 'student')
      }
    } catch {
      localStorage.removeItem('token')
      user.value = null
    }
  }

  function enterAdmin() {
    if (!user.value?.canManage) return false
    portalMode.value = 'admin'
    localStorage.setItem(PORTAL_KEY, 'admin')
    return true
  }

  function enterStudent() {
    portalMode.value = 'student'
    localStorage.setItem(PORTAL_KEY, 'student')
  }

  function logout() {
    localStorage.removeItem('token')
    localStorage.removeItem(PORTAL_KEY)
    user.value = null
    portalMode.value = 'student'
  }

  return {
    user,
    portalMode,
    isLoggedIn,
    canManage,
    login,
    fetchMe,
    enterAdmin,
    enterStudent,
    logout,
  }
})
