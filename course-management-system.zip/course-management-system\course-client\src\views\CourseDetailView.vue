<template>
  <div class="detail page-container">
    <button type="button" class="detail__back" @click="router.back()">← 返回</button>
    <p v-if="error" class="detail__error">{{ error }}</p>
    <div v-else-if="course" class="detail__card">
      <div class="detail__cover" :class="coverTheme">
        <div class="cover-lines" aria-hidden="true" />
        <b class="detail__cover-brand">
          凡岛大学
          <br />
          COURSE
        </b>
      </div>
      <div class="detail__body">
        <div class="detail__tags">
          <StatusBadge v-if="course.isHot" label="热门" type="hot" />
          <StatusBadge v-if="course.isLive" label="直播课" type="live" />
        </div>
        <div class="detail__title-row">
          <h1>{{ course.title }}</h1>
          <button
            type="button"
            class="detail__fav"
            :class="{ on: course.isFavorited }"
            @click="onToggleFavorite"
          >
            {{ course.isFavorited ? '已收藏' : '收藏' }}
          </button>
        </div>
        <p>讲师：{{ course.lecturerName }} · {{ course.departmentName }}</p>
        <p>
          {{ course.plannedDate }}({{ course.weekday }}) {{ course.startTime }}-{{ course.endTime }}
          · {{ course.location }}
        </p>
        <p class="detail__rating">
          <template v-if="course.ratingCount > 0 && ratingAvgText">
            学员评价 ⭐ {{ ratingAvgText }}（{{ course.ratingCount }}人）
          </template>
          <template v-else>暂无评分</template>
          <template v-if="myRatingText"> · 我的评分 ⭐ {{ myRatingText }}</template>
        </p>

        <div v-if="course.canEvaluate" class="detail__eval-box">
          <p>课程已完成，欢迎对本次学习打分</p>
          <button type="button" class="btn btn-primary" @click="evalOpen = true">去评价</button>
        </div>

        <p class="detail__count">{{ course.studentCount }} 人已报名</p>
        <button
          type="button"
          class="btn btn-primary"
          :disabled="course.isEnrolled || enrolling"
          @click="onEnroll"
        >
          {{ course.isEnrolled ? '已报名' : enrolling ? '报名中…' : '立即报名' }}
        </button>
      </div>
    </div>
    <EmptyState v-else-if="!loading" text="课程不存在" />

    <EvaluateModal
      v-if="course"
      :open="evalOpen"
      :course-id="course.id"
      :course-title="course.title"
      @close="evalOpen = false"
      @success="onEvalSuccess"
    />
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { fetchCourseDetail } from '@/api/courses'
import { enrollCourse } from '@/api/enrollments'
import { toggleFavorite } from '@/api/favorites'
import StatusBadge from '@/components/common/StatusBadge.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import EvaluateModal from '@/components/course/EvaluateModal.vue'
import type { Course } from '@/types/course'
import { resolveCoverTheme } from '@/utils/coverTheme'

const route = useRoute()
const router = useRouter()
const course = ref<Course | null>(null)

const coverTheme = computed(() =>
  course.value
    ? resolveCoverTheme({
        id: course.value.id,
        isHot: course.value.isHot,
        isNew: course.value.isNew,
      })
    : 'blue',
)
const loading = ref(true)
const error = ref('')
const enrolling = ref(false)
const evalOpen = ref(false)
const favBusy = ref(false)

function formatScore(value: unknown) {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) ? n.toFixed(1) : ''
}

const ratingAvgText = computed(() => formatScore(course.value?.ratingAvg))
const myRatingText = computed(() => formatScore(course.value?.myRating))

async function loadDetail() {
  loading.value = true
  error.value = ''
  course.value = null
  evalOpen.value = false
  try {
    course.value = await fetchCourseDetail(Number(route.params.id))
  } catch (e) {
    error.value = e instanceof Error ? e.message : '加载失败'
  } finally {
    loading.value = false
  }
}

onMounted(loadDetail)
watch(
  () => route.params.id,
  () => {
    if (route.name === 'course-detail') loadDetail()
  },
)

async function onEnroll() {
  if (!course.value || course.value.isEnrolled) return
  enrolling.value = true
  try {
    await enrollCourse(course.value.id)
    course.value.isEnrolled = true
    course.value.studentCount += 1
  } catch (e) {
    error.value = e instanceof Error ? e.message : '报名失败'
  } finally {
    enrolling.value = false
  }
}

async function onToggleFavorite() {
  if (!course.value || favBusy.value) return
  favBusy.value = true
  const prev = course.value.isFavorited
  try {
    const res = await toggleFavorite(course.value.id, prev)
    course.value.isFavorited = res.favorited
  } catch (e) {
    error.value = e instanceof Error ? e.message : '收藏操作失败'
  } finally {
    favBusy.value = false
  }
}

function onEvalSuccess(avg: number) {
  if (!course.value) return
  course.value.canEvaluate = false
  course.value.myRating = avg
  course.value.ratingCount += 1
  const prevSum = (course.value.ratingAvg ?? 0) * (course.value.ratingCount - 1)
  course.value.ratingAvg = Number(((prevSum + avg) / course.value.ratingCount).toFixed(1))
  evalOpen.value = false
}
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;
@use '@/styles/course-cover.scss' as cover;

.detail__back {
  border: none;
  background: transparent;
  color: $text-secondary;
  font-size: 14px;
  cursor: pointer;
  margin-bottom: 16px;
  padding: 0;

  &:hover {
    color: $primary;
  }
}

.detail__error {
  color: #ef4444;
  margin-bottom: 12px;
}

.detail__card {
  @include card;
  display: grid;
  grid-template-columns: 320px 1fr;
  overflow: hidden;
  background: #fff;

  @include mobile {
    grid-template-columns: 1fr;
  }
}

.detail__cover {
  @include cover.course-cover-base;
  min-height: 220px;
  padding: 16px;
}

.cover-lines {
  @include cover.course-cover-lines;
}

.detail__cover-brand {
  @include cover.course-cover-brand;
}

.detail__body {
  padding: 28px;

  h1 {
    font-size: 24px;
    margin: 0;
    color: $text-title;
    flex: 1;
    min-width: 0;
  }

  p {
    color: $text-secondary;
    margin-bottom: 8px;
    line-height: 1.5;
  }
}

.detail__title-row {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  margin: 12px 0;
}

.detail__fav {
  flex-shrink: 0;
  height: 32px;
  padding: 0 14px;
  border-radius: 16px;
  border: 1px solid #e5e7eb;
  background: #fff;
  color: $text-secondary;
  font-size: 13px;
  cursor: pointer;

  &:hover {
    border-color: #fca5a5;
    color: #ef4444;
  }

  &.on {
    border-color: #fecaca;
    background: #fef2f2;
    color: #ef4444;
  }
}

.detail__tags {
  display: flex;
  gap: 8px;
}

.detail__rating {
  color: #d97706 !important;
  margin-top: 8px !important;
}

.detail__eval-box {
  margin: 16px 0;
  padding: 14px 16px;
  border-radius: 10px;
  background: linear-gradient(135deg, #eff4ff 0%, #f5f8ff 100%);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;

  p {
    margin: 0 !important;
    color: $text-title !important;
    font-size: 14px;
    font-weight: 500;
  }

  .btn {
    flex-shrink: 0;
    height: 34px;
    padding: 0 16px;
  }
}

.detail__count {
  margin: 12px 0 20px !important;
  color: $text-muted !important;
}
</style>
