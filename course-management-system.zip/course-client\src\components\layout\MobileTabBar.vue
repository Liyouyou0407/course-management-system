<template>
  <nav class="tabbar">
    <RouterLink
      v-for="item in items"
      :key="item.to"
      :to="item.to"
      class="tabbar__item"
      :class="{ active: isActive(item.to) }"
    >
      <span class="tabbar__icon" v-html="item.icon" />
      <span>{{ item.label }}</span>
    </RouterLink>
  </nav>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'

const route = useRoute()

const items = [
  {
    label: '首页',
    to: '/',
    icon: '<svg viewBox="0 0 24 24" fill="none"><path d="M4 10.5L12 4l8 6.5V20a1 1 0 01-1 1h-5v-6H10v6H5a1 1 0 01-1-1v-9.5z" stroke="currentColor" stroke-width="1.6"/></svg>',
  },
  {
    label: '课程',
    to: '/courses',
    icon: '<svg viewBox="0 0 24 24" fill="none"><rect x="4" y="5" width="16" height="14" rx="2" stroke="currentColor" stroke-width="1.6"/><path d="M8 9h8M8 13h5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
  },
  {
    label: '我的课',
    to: '/my-learning',
    icon: '<svg viewBox="0 0 24 24" fill="none"><path d="M4 6.5A2.5 2.5 0 016.5 4H20v14H6.5A2.5 2.5 0 004 15.5v-9z" stroke="currentColor" stroke-width="1.6"/><path d="M8 8h8M8 12h5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
  },
  {
    label: '我的',
    to: '/profile',
    icon: '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="9" r="3.5" stroke="currentColor" stroke-width="1.6"/><path d="M5.5 19c1.2-3 3.5-4.5 6.5-4.5s5.3 1.5 6.5 4.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
  },
]

function isActive(to: string) {
  if (to === '/') return route.path === '/'
  if (to === '/courses') {
    return route.path === '/courses' || route.path.startsWith('/course/')
  }
  return route.path.startsWith(to)
}
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.tabbar {
  display: none;
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 90;
  height: 56px;
  background: #fff;
  border-top: 1px solid $border;
  padding-bottom: env(safe-area-inset-bottom);

  @include mobile {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
  }
}

.tabbar__item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  font-size: 11px;
  color: $text-muted;

  &.active {
    color: $primary;
  }
}

.tabbar__icon {
  width: 22px;
  height: 22px;
  display: block;

  :deep(svg) {
    width: 22px;
    height: 22px;
  }
}
</style>
