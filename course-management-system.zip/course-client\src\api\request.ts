export interface ApiResponse<T> {
  code: number
  message: string
  data: T
}

const BASE_URL = import.meta.env.VITE_API_BASE || '/api/v1'

export class ApiError extends Error {
  code: number
  constructor(message: string, code = 1) {
    super(message)
    this.code = code
  }
}

function clearAuthAndGoLogin() {
  localStorage.removeItem('token')
  const path = window.location.pathname
  if (path !== '/login') {
    const redirect = encodeURIComponent(path + window.location.search)
    window.location.replace(`/login?redirect=${redirect}`)
  }
}

export async function request<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  const token = localStorage.getItem('token')
  const headers = new Headers(options.headers || {})
  if (!(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json')
  }
  if (token) {
    headers.set('Authorization', `Bearer ${token}`)
  }

  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers,
  })

  const json = (await res.json().catch(() => null)) as ApiResponse<T> | null
  if (!json) {
    if (res.status === 401) clearAuthAndGoLogin()
    throw new ApiError(`HTTP ${res.status}`)
  }

  if (json.code === 401 || res.status === 401) {
    // 登录接口本身的 401 不跳转，直接抛错给表单展示
    if (!path.startsWith('/auth/login')) {
      clearAuthAndGoLogin()
    }
    throw new ApiError(json.message || '登录已过期', 401)
  }

  if (json.code !== 0) {
    throw new ApiError(json.message || '请求失败', json.code)
  }
  return json.data
}
