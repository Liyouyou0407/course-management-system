import { request } from './request'
import type { MyCourse, MyCourseFilter, PageResult } from '@/types/course'

export function fetchMyCourses(params: {
  page?: number
  page_size?: number
  status?: MyCourseFilter
}) {
  const q = new URLSearchParams()
  if (params.page) q.set('page', String(params.page))
  if (params.page_size) q.set('page_size', String(params.page_size))
  if (params.status) q.set('status', params.status)
  return request<PageResult<MyCourse> & { counts: Record<string, number> }>(
    `/my-courses?${q.toString()}`,
  )
}
