<template>
  <div v-if="open" class="mask" @click.self="$emit('close')">
    <div class="modal">
      <div class="modal__head">
        <h3>评价课程</h3>
        <button type="button" class="modal__close" @click="$emit('close')">×</button>
      </div>
      <p class="modal__title">{{ courseTitle }}</p>

      <div v-for="item in dims" :key="item.key" class="dim">
        <span>{{ item.label }}</span>
        <div class="stars">
          <button
            v-for="n in 5"
            :key="n"
            type="button"
            class="star"
            :class="{ on: scores[item.key] >= n }"
            @click="scores[item.key] = n"
          >
            ★
          </button>
          <em>{{ scores[item.key].toFixed(1) }}</em>
        </div>
      </div>

      <label class="feedback">
        <span>文字反馈（选填）</span>
        <textarea v-model="feedback" rows="3" maxlength="500" placeholder="说说这门课的收获…" />
      </label>

      <p v-if="error" class="error">{{ error }}</p>

      <div class="modal__actions">
        <button type="button" class="btn btn-ghost" @click="$emit('close')">取消</button>
        <button type="button" class="btn btn-primary" :disabled="loading" @click="submit">
          {{ loading ? '提交中…' : '提交评价' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, watch } from 'vue'
import { submitEvaluation } from '@/api/evaluations'

const props = defineProps<{
  open: boolean
  courseId: number
  courseTitle: string
}>()

const emit = defineEmits<{
  close: []
  success: [avg: number]
}>()

type DimKey = 'experience' | 'fluency' | 'practicality' | 'inspiration'

const dims: Array<{ key: DimKey; label: string }> = [
  { key: 'experience', label: '体验感' },
  { key: 'fluency', label: '讲解流畅度' },
  { key: 'practicality', label: '实用性' },
  { key: 'inspiration', label: '启发性' },
]

const scores = reactive<Record<DimKey, number>>({
  experience: 5,
  fluency: 5,
  practicality: 5,
  inspiration: 5,
})
const feedback = ref('')
const loading = ref(false)
const error = ref('')

watch(
  () => props.open,
  (v) => {
    if (v) {
      scores.experience = 5
      scores.fluency = 5
      scores.practicality = 5
      scores.inspiration = 5
      feedback.value = ''
      error.value = ''
    }
  },
)

async function submit() {
  loading.value = true
  error.value = ''
  try {
    const data = await submitEvaluation({
      course_id: props.courseId,
      score_experience: scores.experience,
      score_fluency: scores.fluency,
      score_practicality: scores.practicality,
      score_inspiration: scores.inspiration,
      feedback: feedback.value.trim() || undefined,
    })
    emit('success', data.avg_score)
    emit('close')
  } catch (e) {
    error.value = e instanceof Error ? e.message : '提交失败'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped lang="scss">
.mask {
  position: fixed;
  inset: 0;
  z-index: 200;
  background: rgba(15, 23, 42, 0.45);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.modal {
  width: 100%;
  max-width: 440px;
  background: #fff;
  border-radius: 14px;
  padding: 22px 22px 18px;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.18);
}

.modal__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;

  h3 {
    font-size: 18px;
    color: $text-title;
  }
}

.modal__close {
  border: none;
  background: transparent;
  font-size: 24px;
  line-height: 1;
  color: $text-muted;
  cursor: pointer;
}

.modal__title {
  font-size: 14px;
  color: $text-secondary;
  margin-bottom: 16px;
}

.dim {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
  font-size: 14px;
  color: $text-body;
}

.stars {
  display: flex;
  align-items: center;
  gap: 2px;

  em {
    margin-left: 8px;
    font-style: normal;
    color: $primary;
    font-weight: 600;
    min-width: 28px;
  }
}

.star {
  border: none;
  background: transparent;
  color: #d1d5db;
  font-size: 20px;
  cursor: pointer;
  padding: 0 1px;

  &.on {
    color: #f5a623;
  }
}

.feedback {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 8px;
  font-size: 13px;
  color: $text-secondary;

  textarea {
    border: 1px solid $border;
    border-radius: 8px;
    padding: 10px 12px;
    resize: vertical;
    font: inherit;
    outline: none;

    &:focus {
      border-color: $primary;
    }
  }
}

.error {
  color: #ef4444;
  font-size: 13px;
  margin-top: 10px;
}

.modal__actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 16px;
}
</style>
