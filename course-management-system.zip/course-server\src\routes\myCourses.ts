import { Router } from 'express'
import { prisma } from '../lib/prisma'
import { getRatingMap, mapMyCourse } from '../lib/courseMap'
import { ok, pageData } from '../lib/response'
import { authRequired, type AuthRequest } from '../middleware/auth'

const router = Router()

router.get('/', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const page = Math.max(1, Number(req.query.page) || 1)
  const pageSize = Math.max(1, Math.min(50, Number(req.query.page_size) || 10))
  const status = String(req.query.status || 'all')

  const enrollments = await prisma.enrollment.findMany({
    where: { studentId: userId, status: 'approved' },
    include: { course: { include: { department: true } } },
    orderBy: { signedUpAt: 'desc' },
  })

  const courseIds = enrollments.map((e) => e.courseId)
  const [progresses, evals, ratings] = await Promise.all([
    prisma.learningProgress.findMany({
      where: { userId, courseId: { in: courseIds } },
    }),
    prisma.evaluation.findMany({
      where: { studentId: userId, courseId: { in: courseIds } },
    }),
    getRatingMap(courseIds),
  ])
  const progressMap = new Map(progresses.map((p) => [p.courseId, p]))
  const evalMap = new Map(evals.map((e) => [e.courseId, e]))

  let list = enrollments.map((e) => {
    const rating = ratings.get(e.courseId) || { avg: null, count: 0 }
    return mapMyCourse(
      e,
      progressMap.get(e.courseId) || null,
      evalMap.get(e.courseId) || null,
      rating.avg,
      rating.count,
    )
  })

  const counts = {
    all: list.length,
    in_progress: list.filter((i) => i.learnStatus === 'in_progress').length,
    not_started: list.filter((i) => i.learnStatus === 'not_started').length,
    completed: list.filter((i) => i.learnStatus === 'completed').length,
  }

  if (status !== 'all') {
    list = list.filter((i) => i.learnStatus === status)
  }

  const total = list.length
  const paged = list.slice((page - 1) * pageSize, page * pageSize)
  return ok(res, { ...pageData(paged, total, page, pageSize), counts })
})

export default router
