<template>
  <div class="stat-card">
    <div class="stat-card__icon" :class="tone">
      <slot name="icon" />
    </div>
    <div class="stat-card__content">
      <div class="stat-card__value-row">
        <span class="stat-card__value">{{ value }}</span>
        <span class="stat-card__label">{{ label }}</span>
      </div>
      <p class="stat-card__desc">{{ desc }}</p>
    </div>
  </div>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    value: string | number
    label: string
    desc: string
    tone?: 'blue' | 'green' | 'mint' | 'sky'
  }>(),
  { tone: 'blue' },
)
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.stat-card {
  @include card;
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 18px 20px;
  background: #fff;
}

.stat-card__icon {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;

  :deep(svg) {
    width: 22px;
    height: 22px;
  }

  &.blue {
    background: #e8efff;
    color: $primary;
  }

  &.green {
    background: #e8faf0;
    color: $success;
  }

  &.mint {
    background: #e7f8f3;
    color: #14b8a6;
  }

  &.sky {
    background: #e8f4ff;
    color: #3b82f6;
  }
}

.stat-card__value-row {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 4px;
}

.stat-card__value {
  font-size: $font-size-metric;
  font-weight: 700;
  color: $text-title;
  line-height: 1;
}

.stat-card__label {
  font-size: 14px;
  color: $text-body;
  font-weight: 500;
}

.stat-card__desc {
  font-size: 12px;
  color: $text-muted;
}
</style>
