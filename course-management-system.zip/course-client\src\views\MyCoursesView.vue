<template>
  <div class="my page-container">
    <div class="my__toolbar">
      <CategoryTabs v-model="status" :tabs="tabs" />
      <div class="my__actions">
        <button type="button" class="sort-btn" @click="load">最新学习时间 ↕</button>
      </div>
    </div>

    <p v-if="error" class="my__error">{{ error }}</p>
    <EmptyState v-else-if="!loading && list.length === 0" text="当前筛选下暂无课程" />

    <div v-else class="my__list">
      <MyCourseItem
        v-for="item in list"
        :key="item.id"
        :course="item"
        @continue="onDetail"
        @detail="onDetail"
        @evaluate="openEvaluate"
      />
    </div>

    <Pagination
      v-model:page="page"
      v-model:page-size="pageSize"
      :total="total"
      :page-sizes="[4, 10, 12]"
    />

    <EvaluateModal
      :open="evalOpen"
      :course-id="evalTarget?.courseId || 0"
      :course-title="evalTarget?.courseTitle || ''"
      @close="evalOpen = false"
      @success="onEvalSuccess"
    />
  </div>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import CategoryTabs from '@/components/course/CategoryTabs.vue'
import MyCourseItem from '@/components/course/MyCourseItem.vue'
import EvaluateModal from '@/components/course/EvaluateModal.vue'
import Pagination from '@/components/common/Pagination.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import { fetchMyCourses } from '@/api/myCourses'
import type { MyCourse, MyCourseFilter } from '@/types/course'

const router = useRouter()
const status = ref<MyCourseFilter>('all')
const page = ref(1)
const pageSize = ref(10)
const total = ref(0)
const loading = ref(false)
const error = ref('')
const list = ref<MyCourse[]>([])
const counts = ref({ all: 0, in_progress: 0, not_started: 0, completed: 0 })

const evalOpen = ref(false)
const evalTarget = ref<MyCourse | null>(null)

const tabs = computed(() => [
  { key: 'all', label: '全部课程', count: counts.value.all },
  { key: 'in_progress', label: '进行中', count: counts.value.in_progress },
  { key: 'not_started', label: '未开始', count: counts.value.not_started },
  { key: 'completed', label: '已完成', count: counts.value.completed },
])

async function load() {
  loading.value = true
  error.value = ''
  try {
    const data = await fetchMyCourses({
      page: page.value,
      page_size: pageSize.value,
      status: status.value,
    })
    list.value = data.list
    total.value = data.total
    if (data.counts) {
      counts.value = {
        all: data.counts.all || 0,
        in_progress: data.counts.in_progress || 0,
        not_started: data.counts.not_started || 0,
        completed: data.counts.completed || 0,
      }
    }
  } catch (e) {
    error.value = e instanceof Error ? e.message : '加载失败'
  } finally {
    loading.value = false
  }
}

watch(status, () => {
  page.value = 1
  load()
})
watch([page, pageSize], () => load())
load()

function onDetail(course: MyCourse) {
  router.push({ name: 'course-detail', params: { id: String(course.courseId) } })
}

function openEvaluate(course: MyCourse) {
  evalTarget.value = course
  evalOpen.value = true
}

function onEvalSuccess(avg: number) {
  if (!evalTarget.value) return
  const item = list.value.find((i) => i.id === evalTarget.value!.id)
  if (item) {
    item.canEvaluate = false
    item.myRating = avg
    item.score = avg
  }
  evalOpen.value = false
}
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.my__toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 18px;
  flex-wrap: wrap;
}

.my__actions {
  display: flex;
  align-items: center;
  gap: 12px;
}

.sort-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 34px;
  padding: 0 10px;
  border: none;
  background: transparent;
  color: $text-secondary;
  font-size: 13px;
  cursor: pointer;
  border-radius: 6px;

  &:hover {
    color: $primary;
    background: $primary-light;
  }
}

.my__error {
  color: #ef4444;
  font-size: 13px;
  margin-bottom: 12px;
}

.my__list {
  display: flex;
  flex-direction: column;
  gap: 14px;
}
</style>
