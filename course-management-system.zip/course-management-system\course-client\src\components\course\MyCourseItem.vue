<template>
  <article class="my-course">
    <div class="my-course__cover" :class="coverTheme">
      <span class="my-course__cover-badge">{{ coverBadge }}</span>
      <div class="cover-lines" aria-hidden="true" />
      <b class="my-course__brand">
        凡岛大学
        <br />
        COURSE
      </b>
    </div>

    <div class="my-course__main">
      <div class="my-course__tags">
        <span>{{ primaryTag }}</span>
        <i>{{ course.departmentName || '凡岛大学' }}</i>
      </div>
      <div class="my-course__header">
        <h3 class="my-course__title">{{ course.courseTitle }}</h3>
        <span class="my-course__badge" :class="course.learnStatus">{{ statusLabel }}</span>
      </div>
      <p class="my-course__meta">
        {{ course.plannedDate }}({{ course.weekday }}) · {{ course.startTime }}-{{ course.endTime }}
      </p>
      <div class="my-course__info">
        <span>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="12" cy="8" r="4" stroke="currentColor" stroke-width="1.8" />
            <path d="M4 21a8 8 0 0 1 16 0" stroke="currentColor" stroke-width="1.8" />
          </svg>
          {{ course.lecturerName }}
        </span>
        <span v-if="ratingText" class="rating">★ {{ ratingText }}</span>
        <span>{{ course.location }}</span>
      </div>
    </div>

    <div class="my-course__aside">
      <template v-if="course.learnStatus === 'in_progress'">
        <div class="aside-label">
          <span>学习进度</span>
          <strong>{{ course.progressPercent }}%</strong>
        </div>
        <ProgressBar :percent="course.progressPercent" />
        <p class="aside-meta">上次学习：{{ course.lastStudyAt }}</p>
        <button type="button" class="btn btn-primary" @click="$emit('continue', course)">
          继续学习
        </button>
      </template>

      <template v-else-if="course.learnStatus === 'not_started'">
        <p class="aside-label soft">开始时间</p>
        <p class="aside-time">{{ course.startDate }}</p>
        <button type="button" class="btn btn-outline" @click="$emit('detail', course)">
          查看详情
        </button>
      </template>

      <template v-else>
        <p class="aside-label soft">完成日期</p>
        <p class="aside-time">{{ course.completedAt }}</p>
        <template v-if="course.canEvaluate">
          <p class="aside-eval-hint">完成学习后可进行四维评分</p>
          <button type="button" class="btn btn-primary aside-eval-btn" @click="$emit('evaluate', course)">
            去评价
          </button>
        </template>
        <template v-else>
          <p v-if="ratedText" class="aside-meta">已评价 ★ {{ ratedText }}</p>
          <button type="button" class="btn btn-outline" @click="$emit('detail', course)">
            查看详情
          </button>
        </template>
      </template>
    </div>
  </article>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { MyCourse } from '@/types/course'
import ProgressBar from '@/components/common/ProgressBar.vue'
import { resolveCoverTheme } from '@/utils/coverTheme'

const props = defineProps<{ course: MyCourse }>()

defineEmits<{
  continue: [course: MyCourse]
  detail: [course: MyCourse]
  evaluate: [course: MyCourse]
}>()

const coverTheme = computed(() =>
  resolveCoverTheme({ id: props.course.courseId }),
)

const coverBadge = computed(() => {
  if (props.course.tag === 'live') return '直播课'
  if (props.course.learnStatus === 'completed') return '已完成'
  if (props.course.learnStatus === 'not_started') return '未开始'
  return '学习中'
})

const primaryTag = computed(() => {
  if (props.course.tag === 'live') return '直播课'
  if (props.course.tag === 'upcoming') return '即将开课'
  return '我的课程'
})

const statusLabel = computed(() => {
  const map = {
    in_progress: '进行中',
    not_started: '未开始',
    completed: '已完成',
  }
  return map[props.course.learnStatus]
})

const ratedText = computed(() => {
  const raw = props.course.myRating ?? props.course.score
  if (raw == null) return ''
  const n = typeof raw === 'number' ? raw : Number(raw)
  return Number.isFinite(n) ? n.toFixed(1) : ''
})

const ratingText = computed(() => {
  const raw = props.course.ratingAvg
  if (raw == null) return ''
  const n = typeof raw === 'number' ? raw : Number(raw)
  return Number.isFinite(n) ? n.toFixed(1) : ''
})
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;
@use '@/styles/course-cover.scss' as cover;

.my-course {
  display: grid;
  grid-template-columns: 200px 1fr 200px;
  gap: 0;
  background: #fff;
  border: 1px solid #e1e9f2;
  border-radius: 15px;
  overflow: hidden;
  transition: box-shadow 0.25s ease, transform 0.25s ease;

  &:hover {
    box-shadow: 0 18px 60px rgba(29, 71, 126, 0.1);
    transform: translateY(-2px);
  }

  @include mobile {
    grid-template-columns: 1fr;
  }
}

.my-course__cover {
  @include cover.course-cover-base;
  min-height: 140px;
  padding: 14px;

  @include mobile {
    min-height: 120px;
  }
}

.my-course__cover-badge {
  @include cover.course-cover-badge;
}

.cover-lines {
  @include cover.course-cover-lines;
}

.my-course__brand {
  @include cover.course-cover-brand;
}

.my-course__main {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
  padding: 18px 20px;
}

.my-course__tags {
  display: flex;
  align-items: center;
  gap: 7px;

  span,
  i {
    border-radius: 4px;
    padding: 4px 7px;
    font-size: 11px;
    font-weight: 650;
    font-style: normal;
    line-height: 1;
  }

  span {
    color: #2369bd;
    background: #eaf3ff;
  }

  i {
    color: #68788b;
    background: #f1f4f7;
  }
}

.my-course__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}

.my-course__title {
  margin: 0;
  font-size: 17px;
  font-weight: 750;
  color: $text-title;
  line-height: 1.45;
}

.my-course__badge {
  flex-shrink: 0;
  height: 24px;
  padding: 0 10px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  display: inline-flex;
  align-items: center;

  &.in_progress {
    background: $primary-light;
    color: $primary;
  }

  &.not_started {
    background: $warning-soft;
    color: $warning;
  }

  &.completed {
    background: #f1f4f7;
    color: $text-secondary;
  }
}

.my-course__meta {
  margin: 0;
  font-size: 13px;
  font-weight: 500;
  color: #8090a2;
}

.my-course__info {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px 14px;
  font-size: 12px;
  font-weight: 500;
  color: #8896a7;

  span {
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }

  .rating {
    color: #e9992c;
  }
}

.my-course__aside {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 10px;
  padding: 18px 20px;
  border-left: 1px solid #eef3f9;

  @include mobile {
    border-left: none;
    border-top: 1px solid #eef3f9;
  }

  .btn {
    width: 100%;
    font-size: 14px;
  }
}

.aside-label {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
  color: $text-secondary;

  strong {
    color: $primary;
    font-size: 16px;
  }

  &.soft {
    color: $text-muted;
  }
}

.aside-time {
  font-size: 17px;
  font-weight: 650;
  color: $text-title;
  line-height: 1.3;
}

.aside-meta {
  font-size: 12px;
  color: $text-muted;
}

.aside-eval-hint {
  font-size: 12px;
  color: #d97706;
  line-height: 1.4;
}

.aside-eval-btn {
  box-shadow: 0 4px 12px rgba(23, 105, 224, 0.22);
}
</style>
