export const COVER_THEMES = ['sky', 'blue', 'deep', 'navy'] as const
export type CoverTheme = (typeof COVER_THEMES)[number]

/** Map course flags / id to a blue-only cover theme */
export function resolveCoverTheme(opts: {
  id: number
  isHot?: boolean
  isNew?: boolean
}): CoverTheme {
  if (opts.isHot) return 'deep'
  if (opts.isNew) return 'sky'
  return COVER_THEMES[Math.abs(opts.id) % COVER_THEMES.length]
}
