<template>
  <div class="login">
    <div class="login__card">
      <div class="login__brand">
        <img class="login__logo" src="/fandow-logo.png" alt="Fandow" />
        <div>
          <h1>课程管理系统</h1>
          <p>学员端登录</p>
        </div>
      </div>

      <form class="login__form" @submit.prevent="onSubmit">
        <label>
          <span>账号</span>
          <input v-model="username" type="text" placeholder="请输入账号" autocomplete="username" />
        </label>
        <label>
          <span>密码</span>
          <input
            v-model="password"
            type="password"
            placeholder="请输入密码"
            autocomplete="current-password"
          />
        </label>
        <p v-if="error" class="login__error">{{ error }}</p>
        <button type="submit" class="btn btn-primary login__submit" :disabled="loading">
          {{ loading ? '登录中...' : '登录' }}
        </button>
        <p class="login__hint">演示账号：lifengyun / 123456（可切换管理端）</p>
        <p class="login__hint soft">纯学员：demo / 123456</p>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const username = ref('lifengyun')
const password = ref('123456')
const error = ref('')
const loading = ref(false)

onMounted(() => {
  // 进入登录页时清掉失效/mock token，避免接口一直 401
  const token = localStorage.getItem('token')
  if (token && token.split('.').length !== 3) {
    localStorage.removeItem('token')
    userStore.logout()
  }
})

async function onSubmit() {
  if (!username.value.trim()) {
    error.value = '请输入账号'
    return
  }
  if (!password.value) {
    error.value = '请输入密码'
    return
  }
  loading.value = true
  error.value = ''
  try {
    await userStore.login(username.value.trim(), password.value)
    const redirect = (route.query.redirect as string) || '/'
    router.replace(redirect)
  } catch (e) {
    error.value = e instanceof Error ? e.message : '登录失败'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped lang="scss">
.login {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  background:
    radial-gradient(circle at 20% 20%, rgba(45, 91, 255, 0.12), transparent 40%),
    radial-gradient(circle at 80% 10%, rgba(99, 140, 255, 0.16), transparent 35%),
    linear-gradient(160deg, #f7f8fc, #eef2ff 60%, #fafbff);
}

.login__card {
  width: 100%;
  max-width: 420px;
  background: #fff;
  border-radius: 16px;
  padding: 36px 32px;
  box-shadow: 0 16px 48px rgba(45, 91, 255, 0.1);
}

.login__brand {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 28px;

  .login__logo {
    width: 48px;
    height: 48px;
    object-fit: contain;
    border-radius: 10px;
    flex-shrink: 0;
  }

  h1 {
    font-size: 18px;
    color: $text-title;
    margin-bottom: 4px;
  }

  p {
    font-size: 13px;
    color: $text-muted;
  }
}

.login__form {
  display: flex;
  flex-direction: column;
  gap: 16px;

  label {
    display: flex;
    flex-direction: column;
    gap: 8px;
    font-size: 13px;
    color: $text-secondary;
  }

  input {
    height: 44px;
    padding: 0 14px;
    border: 1px solid $border;
    border-radius: 10px;
    font-size: 14px;
    outline: none;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;

    &:focus {
      border-color: $primary;
      box-shadow: 0 0 0 3px rgba(45, 91, 255, 0.12);
    }
  }
}

.login__submit {
  height: 44px;
  width: 100%;
  margin-top: 4px;
  border-radius: 10px;
  font-size: 15px;
}

.login__error {
  color: #ef4444;
  font-size: 13px;
}

.login__hint {
  text-align: center;
  font-size: 12px;
  color: $text-muted;
  margin-top: 8px;

  &.soft {
    margin-top: 4px;
    opacity: 0.85;
  }
}
</style>
