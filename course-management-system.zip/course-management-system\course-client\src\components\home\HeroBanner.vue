<template>
  <section class="hero">
    <div class="hero__content">
      <h1 class="hero__title">
        欢迎回来，{{ userName }}
        <span class="hero__wave" aria-hidden="true">👋</span>
      </h1>
      <p class="hero__subtitle">今天是学习的好日子，继续加油！</p>
      <button type="button" class="btn btn-primary hero__btn" @click="$emit('cta')">
        查看我的课程
      </button>
    </div>
    <div class="hero__art" aria-hidden="true">
      <svg viewBox="0 0 280 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="cap" x1="80" y1="20" x2="200" y2="100" gradientUnits="userSpaceOnUse">
            <stop stop-color="#8BA4FF" />
            <stop offset="1" stop-color="#2D5BFF" />
          </linearGradient>
          <linearGradient id="book1" x1="60" y1="100" x2="200" y2="160" gradientUnits="userSpaceOnUse">
            <stop stop-color="#7B93FF" />
            <stop offset="1" stop-color="#4A6BFF" />
          </linearGradient>
          <linearGradient id="book2" x1="70" y1="90" x2="210" y2="140" gradientUnits="userSpaceOnUse">
            <stop stop-color="#A8B8FF" />
            <stop offset="1" stop-color="#6B88FF" />
          </linearGradient>
        </defs>
        <ellipse cx="170" cy="168" rx="95" ry="18" fill="#D9E2FF" opacity="0.85" />
        <!-- books stack -->
        <rect x="78" y="128" width="130" height="20" rx="3" fill="url(#book1)" />
        <rect x="86" y="110" width="130" height="20" rx="3" fill="url(#book2)" />
        <rect x="94" y="92" width="130" height="20" rx="3" fill="#B4C3FF" />
        <!-- graduation cap -->
        <path d="M140 42l78 34-78 34-78-34 78-34z" fill="url(#cap)" />
        <path d="M96 84v28c18 12 50 18 88 0V84" fill="#5B7CFF" opacity="0.9" />
        <rect x="136" y="74" width="8" height="30" rx="2" fill="#3D5FE8" />
        <circle cx="140" cy="108" r="5" fill="#FFD166" />
        <path d="M140 108c10 2 18 10 20 22" stroke="#FFD166" stroke-width="2" stroke-linecap="round" />
        <!-- decorative cubes -->
        <g opacity="0.9">
          <rect x="228" y="68" width="26" height="26" rx="5" fill="#9EB0FF" transform="rotate(18 241 81)" />
          <rect x="38" y="98" width="22" height="22" rx="5" fill="#AEBDFF" transform="rotate(-14 49 109)" />
          <circle cx="230" cy="120" r="10" fill="#C7D2FF" />
        </g>
      </svg>
    </div>
  </section>
</template>

<script setup lang="ts">
defineProps<{ userName: string }>()
defineEmits<{ cta: [] }>()
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.hero {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  padding: 20px 36px;
  border-radius: 16px;
  background: linear-gradient(135deg, #eef2ff, #f5f7ff, #fafbff, #ffffff);
  overflow: hidden;
  position: relative;

  @include mobile {
    padding: 18px 20px;
  }
}

.hero__content {
  position: relative;
  z-index: 1;
}

.hero__title {
  font-size: 30px;
  font-weight: 700;
  color: $text-title;
  margin-bottom: 10px;
  line-height: 1.3;

  @include mobile {
    font-size: 24px;
  }
}

.hero__wave {
  display: inline-block;
  animation: wave 1.8s ease-in-out infinite;
  transform-origin: 70% 70%;
}

@keyframes wave {
  0%,
  100% {
    transform: rotate(0deg);
  }
  20% {
    transform: rotate(16deg);
  }
  40% {
    transform: rotate(-6deg);
  }
  60% {
    transform: rotate(12deg);
  }
}

.hero__subtitle {
  font-size: 15px;
  color: $text-secondary;
  margin-bottom: 14px;
}

.hero__btn {
  height: 40px;
  padding: 0 22px;
  border-radius: 8px;
  font-size: 14px;
}

.hero__art {
  width: 260px;
  flex-shrink: 0;
  animation: float 4s ease-in-out infinite;

  @include mobile {
    display: none;
  }
}

@keyframes float {
  0%,
  100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-8px);
  }
}
</style>
