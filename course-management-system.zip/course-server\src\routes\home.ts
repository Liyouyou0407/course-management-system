import { Router } from 'express'
import { prisma } from '../lib/prisma'
import { getRatingMap, getStudentCountMap, mapCourse } from '../lib/courseMap'
import { ok } from '../lib/response'
import { authRequired, type AuthRequest } from '../middleware/auth'

const router = Router()

router.get('/stats', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const progresses = await prisma.learningProgress.findMany({ where: { userId } })
  const completed = progresses.filter((p) => p.progressPercent >= 100).length
  const inProgress = progresses.filter(
    (p) => p.progressPercent > 0 && p.progressPercent < 100,
  ).length
  const totalHours = Math.round(
    progresses.reduce((sum, p) => sum + p.watchedMinutes, 0) / 60,
  )
  const totalCourses = await prisma.enrollment.count({
    where: { studentId: userId, status: 'approved' },
  })
  return ok(res, {
    totalCourses,
    completed,
    inProgress,
    totalHours: totalHours || 24,
  })
})

router.get('/departments', authRequired, async (_req, res) => {
  const list = await prisma.department.findMany({
    orderBy: { sortOrder: 'asc' },
    select: { id: true, name: true },
  })
  return ok(res, list)
})

router.get('/recommended', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const courses = await prisma.course.findMany({
    where: { status: 'published' },
    include: { department: true },
    orderBy: [{ isHot: 'desc' }, { id: 'asc' }],
    take: 4,
  })
  const ids = courses.map((c) => c.id)
  const [ratings, counts, favorites, enrollments] = await Promise.all([
    getRatingMap(ids),
    getStudentCountMap(ids),
    prisma.favorite.findMany({ where: { userId, courseId: { in: ids } } }),
    prisma.enrollment.findMany({
      where: { studentId: userId, courseId: { in: ids }, status: 'approved' },
    }),
  ])
  const favSet = new Set(favorites.map((f) => f.courseId))
  const enrSet = new Set(enrollments.map((e) => e.courseId))

  return ok(
    res,
    courses.map((c) => {
      const rating = ratings.get(c.id)!
      return mapCourse(c, {
        studentCount: counts.get(c.id) || 0,
        ratingAvg: rating.avg,
        ratingCount: rating.count,
        isFavorited: favSet.has(c.id),
        isEnrolled: enrSet.has(c.id),
      })
    }),
  )
})

export default router
