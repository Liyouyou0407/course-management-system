<template>
  <footer class="footer">
    <div class="page-container">
      <p>凡岛大学·课程管理系统·{{ suffix }}</p>
    </div>
  </footer>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    suffix?: string
  }>(),
  { suffix: '学员端' },
)
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.footer {
  padding: 10px 0 14px;
  color: $text-muted;
  font-size: 12px;
  text-align: center;

  @include mobile {
    padding-bottom: 72px;
  }
}
</style>
