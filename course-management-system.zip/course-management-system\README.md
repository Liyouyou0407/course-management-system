# 凡岛大学 · 课程管理系统

学员端 + 管理端（身份切换）的课程学习与管理平台。

## 功能概览

**学员端**
- 登录 / 首页统计与推荐课程
- 课程中心（搜索、分类、部门筛选、收藏、报名）
- 我的课程（进度、评价）
- 课程详情、消息通知、个人中心

**管理端**（`dept_admin` / `super_admin` 可切换进入）
- 管理概览（指标、报名趋势、最新动态）
- 课程管理（新增 / 编辑 / 查看 / 发布下架）
- 学员管理（搜索、部门筛选、详情）

## 技术栈

| 端 | 技术 |
|----|------|
| 前端 | Vue 3 + Vite + TypeScript + SCSS + Pinia + Vue Router |
| 后端 | Node.js + Express + Prisma + Zod + JWT |
| 数据库 | SQLite（本地零配置；生产可换 MySQL） |

## 环境要求

- Node.js 18+（建议 20）
- npm

## 快速开始

### 1. 启动后端

```bash
cd course-server
npm install
npx prisma db push
npm run db:seed
npm run dev
```

后端默认：`http://localhost:8080`

### 2. 启动前端

```bash
cd course-client
npm install
npm run dev
```

前端默认：`http://localhost:5173`  
（已配置代理，前端请求 `/api` 会转到 8080）

## 演示账号

| 账号 | 密码 | 说明 |
|------|------|------|
| `lifengyun` | `123456` | 部门管理员，头像菜单可「切换到管理端」 |
| `demo` | `123456` | 普通学员，无管理端入口 |

## 文档

| 文档 | 说明 |
|------|------|
| [设计文档 v2.3](凡岛大学课程管理系统%20—%20前后端%20+%20数据库设计文档%20v2.3.md) | UI / 架构 / API / 库表 |
| [过程材料索引 docs/](docs/README.md) | PRD、权限、流程、UAT、数据字典、Tokens 等 |

## 目录说明

```text
course-client/     学员端 + 管理端前端
course-server/     API 与 Prisma / SQLite
docs/              产品过程材料 01–09
设计文档 v2.3.md   前后端 + 数据库规格
```

## 常用说明

- 首次运行务必先 `db push` 再 `db:seed`，否则没有演示数据
- 学习进度、评价样例已在 seed 中写入
- 课程封面展示为蓝系主题四档（`sky/blue/deep/navy`）

## License

仅供学习与实习演示使用。
