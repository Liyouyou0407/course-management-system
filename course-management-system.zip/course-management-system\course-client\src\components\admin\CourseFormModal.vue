<template>
  <div v-if="open" class="mask" @click.self="$emit('close')">
    <div class="modal">
      <div class="modal__head">
        <h3>{{ titleText }}</h3>
        <button type="button" class="modal__close" @click="$emit('close')">×</button>
      </div>

      <form class="form" :class="{ readonly: isView }" @submit.prevent="submit">
        <label>
          <span>课程名称</span>
          <input v-model="form.title" :readonly="isView" required maxlength="100" placeholder="请输入课程名称" />
        </label>
        <label>
          <span>讲师</span>
          <input v-model="form.lecturerName" :readonly="isView" required maxlength="50" placeholder="请输入讲师姓名" />
        </label>
        <label>
          <span>所属部门</span>
          <select v-model.number="form.departmentId" :disabled="isView">
            <option :value="0">未指定</option>
            <option v-for="d in departments" :key="d.id" :value="d.id">{{ d.name }}</option>
          </select>
        </label>
        <div class="form__row">
          <label>
            <span>日期</span>
            <input v-model="form.plannedDate" :readonly="isView" required placeholder="如 08-20" />
          </label>
          <label>
            <span>星期</span>
            <input v-model="form.weekday" :readonly="isView" required placeholder="如 周三" />
          </label>
        </div>
        <div class="form__row">
          <label>
            <span>开始</span>
            <input v-model="form.startTime" :readonly="isView" required placeholder="19:00" />
          </label>
          <label>
            <span>结束</span>
            <input v-model="form.endTime" :readonly="isView" required placeholder="21:00" />
          </label>
        </div>
        <label>
          <span>地点</span>
          <input v-model="form.location" :readonly="isView" placeholder="腾讯会议" />
        </label>
        <div class="form__checks">
          <label class="check">
            <input v-model="form.isHot" type="checkbox" :disabled="isView" /> 热门
          </label>
          <label class="check">
            <input v-model="form.isNew" type="checkbox" :disabled="isView" /> 最新
          </label>
        </div>
        <label v-if="mode === 'edit' || mode === 'view'">
          <span>状态</span>
          <select v-model="form.status" :disabled="isView">
            <option value="draft">未开始</option>
            <option value="published">已上架</option>
            <option value="archived">已归档</option>
          </select>
        </label>
        <label v-if="isView && course">
          <span>报名 / 评分</span>
          <input
            :value="`${course.studentCount} 人报名 · ${ratingText}`"
            readonly
          />
        </label>

        <p v-if="error" class="error">{{ error }}</p>
        <div class="modal__actions">
          <button type="button" class="btn btn-outline" @click="$emit('close')">
            {{ isView ? '关闭' : '取消' }}
          </button>
          <button v-if="!isView" type="submit" class="btn btn-primary" :disabled="loading">
            {{ loading ? '保存中…' : '保存' }}
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import { createAdminCourse, fetchAdminDepartments, updateAdminCourse } from '@/api/admin'
import type { AdminCoursePayload, AdminCourseRow, AdminDepartment } from '@/types/course'

const props = defineProps<{
  open: boolean
  mode: 'create' | 'edit' | 'view'
  course?: AdminCourseRow | null
}>()

const emit = defineEmits<{
  close: []
  success: []
}>()

const departments = ref<AdminDepartment[]>([])
const loading = ref(false)
const error = ref('')

const isView = computed(() => props.mode === 'view')
const titleText = computed(() => {
  if (props.mode === 'create') return '新增课程'
  if (props.mode === 'view') return '查看课程'
  return '编辑课程'
})

const ratingText = computed(() => {
  const c = props.course
  if (!c || c.ratingCount <= 0 || c.ratingAvg == null) return '暂无评分'
  return `⭐ ${Number(c.ratingAvg).toFixed(1)}（${c.ratingCount}人）`
})

const form = reactive({
  title: '',
  lecturerName: '',
  departmentId: 0,
  plannedDate: '',
  weekday: '',
  startTime: '19:00',
  endTime: '21:00',
  location: '腾讯会议',
  isHot: false,
  isNew: true,
  status: 'draft' as 'published' | 'draft' | 'archived',
})

function resetFromCourse() {
  if ((props.mode === 'edit' || props.mode === 'view') && props.course) {
    const c = props.course
    form.title = c.title
    form.lecturerName = c.lecturerName
    form.departmentId = c.departmentId || 0
    form.plannedDate = c.plannedDate
    form.weekday = c.weekday
    form.startTime = c.startTime
    form.endTime = c.endTime
    form.location = c.location || '腾讯会议'
    form.isHot = c.isHot
    form.isNew = c.isNew
    form.status = (c.status as typeof form.status) || 'draft'
  } else {
    form.title = ''
    form.lecturerName = ''
    form.departmentId = 0
    form.plannedDate = ''
    form.weekday = ''
    form.startTime = '19:00'
    form.endTime = '21:00'
    form.location = '腾讯会议'
    form.isHot = false
    form.isNew = true
    form.status = 'draft'
  }
  error.value = ''
}

watch(
  () => props.open,
  async (v) => {
    if (!v) return
    resetFromCourse()
    if (!departments.value.length) {
      departments.value = await fetchAdminDepartments()
    }
  },
)

async function submit() {
  if (isView.value) return
  loading.value = true
  error.value = ''
  const payload: AdminCoursePayload = {
    title: form.title.trim(),
    lecturerName: form.lecturerName.trim(),
    departmentId: form.departmentId || null,
    plannedDate: form.plannedDate.trim(),
    weekday: form.weekday.trim(),
    startTime: form.startTime.trim(),
    endTime: form.endTime.trim(),
    location: form.location.trim() || '腾讯会议',
    isHot: form.isHot,
    isNew: form.isNew,
  }
  try {
    if (props.mode === 'create') {
      await createAdminCourse(payload)
    } else if (props.course) {
      await updateAdminCourse(props.course.id, { ...payload, status: form.status })
    }
    emit('success')
    emit('close')
  } catch (e) {
    error.value = e instanceof Error ? e.message : '保存失败'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.mask {
  position: fixed;
  inset: 0;
  z-index: 200;
  background: rgba(15, 23, 42, 0.35);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.modal {
  width: 100%;
  max-width: 520px;
  max-height: 90vh;
  overflow: auto;
  background: #fff;
  border-radius: 14px;
  padding: 20px 22px 22px;
  box-shadow: 0 20px 48px rgba(15, 23, 42, 0.16);
}

.modal__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;

  h3 {
    font-size: $font-size-title;
    color: $text-title;
  }
}

.modal__close {
  border: none;
  background: transparent;
  font-size: 22px;
  color: $text-muted;
  cursor: pointer;
  line-height: 1;
}

.form {
  display: flex;
  flex-direction: column;
  gap: 12px;

  label {
    display: flex;
    flex-direction: column;
    gap: 6px;
    font-size: 13px;
    color: $text-secondary;
  }

  input,
  select {
    height: 36px;
    border: 1px solid $border;
    border-radius: 8px;
    padding: 0 12px;
    font-size: 14px;
    color: $text-title;
    background: #fff;

    &:focus {
      outline: none;
      border-color: $primary;
    }

    &:disabled {
      color: $text-body;
      background: #f8fafc;
      cursor: default;
    }
  }

  &.readonly input {
    background: #f8fafc;
    color: $text-body;
    cursor: default;
  }
}

.form__row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}

.form__checks {
  display: flex;
  gap: 16px;
}

.check {
  flex-direction: row !important;
  align-items: center;
  gap: 6px !important;
  cursor: pointer;

  input {
    width: 16px;
    height: 16px;
  }
}

.error {
  color: #ef4444;
  font-size: 13px;
}

.modal__actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 8px;

  .btn {
    height: 36px;
    padding: 0 16px;
  }
}
</style>
