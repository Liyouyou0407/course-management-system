<template>
  <div class="admin-courses page-container">
    <div class="admin-courses__toolbar">
      <SearchBar
        v-model="keyword"
        placeholder="搜索课程名称或讲师"
        :show-filter="false"
      />
      <button type="button" class="btn btn-primary admin-courses__add" @click="openCreate">
        + 新增课程
      </button>
    </div>

    <p v-if="error" class="admin-courses__error">{{ error }}</p>
    <EmptyState v-else-if="!loading && list.length === 0" text="没有找到相关课程" />

    <div v-else class="admin-courses__table-wrap">
      <table class="admin-courses__table">
        <thead>
          <tr>
            <th>课程名称</th>
            <th>讲师</th>
            <th>时间</th>
            <th>状态</th>
            <th>报名人数</th>
            <th>评分</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in list" :key="row.id">
            <td>
              <strong>{{ row.title }}</strong>
              <em v-if="row.isHot">热门</em>
              <em v-if="row.isNew" class="neu">最新</em>
            </td>
            <td>{{ row.lecturerName }}</td>
            <td>{{ row.plannedDate }}({{ row.weekday }}) {{ row.startTime }}-{{ row.endTime }}</td>
            <td>
              <span class="status" :class="row.status">{{ statusLabel(row.status) }}</span>
            </td>
            <td>{{ row.studentCount }}</td>
            <td>
              <template v-if="row.ratingCount > 0 && row.ratingAvg != null">
                ⭐ {{ Number(row.ratingAvg).toFixed(1) }}
              </template>
              <template v-else>—</template>
            </td>
            <td class="actions">
              <button type="button" class="link" @click="openEdit(row)">编辑</button>
              <button type="button" class="link" @click="viewCourse(row)">查看</button>
              <button
                v-if="row.status === 'published'"
                type="button"
                class="link"
                :disabled="busyId === row.id"
                @click="setStatus(row, 'draft')"
              >
                下架
              </button>
              <button
                v-else
                type="button"
                class="link"
                :disabled="busyId === row.id"
                @click="setStatus(row, 'published')"
              >
                发布
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <Pagination
      v-model:page="page"
      v-model:page-size="pageSize"
      :total="total"
      :page-sizes="[8, 10, 20]"
    />

    <CourseFormModal
      :open="formOpen"
      :mode="formMode"
      :course="editing"
      @close="formOpen = false"
      @success="load"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import SearchBar from '@/components/common/SearchBar.vue'
import Pagination from '@/components/common/Pagination.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import CourseFormModal from '@/components/admin/CourseFormModal.vue'
import { fetchAdminCourses, updateCourseStatus } from '@/api/admin'
import type { AdminCourseRow } from '@/types/course'

const page = ref(1)
const pageSize = ref(10)
const total = ref(0)
const keyword = ref('')
const loading = ref(false)
const error = ref('')
const list = ref<AdminCourseRow[]>([])
const busyId = ref<number | null>(null)

const formOpen = ref(false)
const formMode = ref<'create' | 'edit' | 'view'>('create')
const editing = ref<AdminCourseRow | null>(null)

function statusLabel(status: string) {
  if (status === 'published') return '已上架'
  if (status === 'archived') return '已归档'
  return '未开始'
}

async function load() {
  loading.value = true
  error.value = ''
  try {
    const data = await fetchAdminCourses({
      page: page.value,
      page_size: pageSize.value,
      keyword: keyword.value.trim(),
    })
    list.value = data.list
    total.value = data.total
  } catch (e) {
    error.value = e instanceof Error ? e.message : '加载失败'
  } finally {
    loading.value = false
  }
}

function reload() {
  page.value = 1
  load()
}

function openCreate() {
  formMode.value = 'create'
  editing.value = null
  formOpen.value = true
}

function openEdit(row: AdminCourseRow) {
  formMode.value = 'edit'
  editing.value = row
  formOpen.value = true
}

function viewCourse(row: AdminCourseRow) {
  formMode.value = 'view'
  editing.value = row
  formOpen.value = true
}

async function setStatus(row: AdminCourseRow, status: 'published' | 'draft') {
  busyId.value = row.id
  error.value = ''
  try {
    const res = await updateCourseStatus(row.id, status)
    row.status = res.status
  } catch (e) {
    error.value = e instanceof Error ? e.message : '更新失败'
  } finally {
    busyId.value = null
  }
}

let keywordTimer: number | undefined
watch(keyword, () => {
  window.clearTimeout(keywordTimer)
  keywordTimer = window.setTimeout(() => reload(), 300)
})

watch([page, pageSize], () => load())
load()
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.admin-courses {
  display: flex;
  flex-direction: column;
}

.admin-courses__toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;

  :deep(.search-bar) {
    flex: 1;
    min-width: 0;
  }
}

.admin-courses__add {
  height: 44px;
  padding: 0 18px;
  flex-shrink: 0;
}

.admin-courses__error {
  color: #ef4444;
  font-size: 13px;
  margin-bottom: 12px;
}

.admin-courses__table-wrap {
  @include card;
  background: #fff;
  overflow: auto;
  margin-bottom: 16px;
  flex: 1;
}

.admin-courses__table {
  width: 100%;
  border-collapse: collapse;
  min-width: 900px;

  th,
  td {
    padding: 14px 16px;
    text-align: left;
    border-bottom: 1px solid #f0f2f7;
    font-size: 14px;
    color: $text-secondary;
    vertical-align: middle;
  }

  th {
    color: $text-muted;
    font-weight: 500;
    font-size: 13px;
    background: #fafbff;
  }

  strong {
    display: block;
    color: $text-title;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 4px;
  }

  em {
    display: inline-block;
    margin-right: 4px;
    font-style: normal;
    font-size: 11px;
    padding: 1px 6px;
    border-radius: 4px;
    background: #fff1e8;
    color: #ea580c;
    border: 1px solid #fdba74;

    &.neu {
      background: $primary-light;
      color: $primary;
      border-color: #bfdbfe;
    }
  }
}

.status {
  display: inline-flex;
  height: 24px;
  padding: 0 10px;
  border-radius: 4px;
  font-size: 12px;
  align-items: center;
  font-weight: 500;

  &.published {
    background: $success-soft;
    color: $success;
  }

  &.draft {
    background: #fff7ed;
    color: #ea580c;
  }

  &.archived {
    background: #fff1f2;
    color: #e11d48;
  }
}

.actions {
  white-space: nowrap;
}

.link {
  border: none;
  background: transparent;
  color: $primary;
  font-size: 13px;
  cursor: pointer;
  padding: 0 8px 0 0;

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  &:hover:not(:disabled) {
    text-decoration: underline;
  }
}
</style>
