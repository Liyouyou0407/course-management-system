<template>
  <div class="progress">
    <div class="progress__track">
      <div class="progress__fill" :style="{ width: `${clamped}%` }" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{ percent: number }>()
const clamped = computed(() => Math.min(100, Math.max(0, props.percent)))
</script>

<style scoped lang="scss">
.progress__track {
  width: 100%;
  height: 8px;
  background: #e8edff;
  border-radius: 999px;
  overflow: hidden;
}

.progress__fill {
  height: 100%;
  background: linear-gradient(90deg, $primary, #6b8cff);
  border-radius: 999px;
  transition: width 0.3s ease;
}
</style>
