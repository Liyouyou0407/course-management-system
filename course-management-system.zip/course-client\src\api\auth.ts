import { request } from './request'
import type { UserInfo } from '@/types/course'

export function loginApi(username: string, password: string) {
  return request<{ token: string; user: UserInfo }>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  })
}

export function meApi() {
  return request<UserInfo>('/auth/me')
}
