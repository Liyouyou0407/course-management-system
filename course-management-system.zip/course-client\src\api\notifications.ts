import { request } from './request'

export interface NotificationItem {
  id: number
  title: string
  content: string
  type: string
  read: boolean
  time: string
}

export function fetchNotifications() {
  return request<NotificationItem[]>('/notifications')
}

export function fetchUnreadCount() {
  return request<{ count: number }>('/notifications/unread-count')
}

export function markAllNotificationsRead() {
  return request<{ ok: boolean }>('/notifications/read-all', {
    method: 'PATCH',
  })
}
