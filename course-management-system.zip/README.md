﻿# 凡岛大学·课程管理系统

解压后：

```bash
cd course-server
npm install
npx prisma db push
npm run db:seed
npm run dev

cd ../course-client
npm install
npm run dev
```

账号：lifengyun / 123456（可切换管理端）；demo / 123456（学员）
