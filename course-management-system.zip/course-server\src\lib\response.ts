import type { Response } from 'express'

export function ok<T>(res: Response, data: T, message = 'success') {
  return res.json({ code: 0, message, data })
}

export function fail(res: Response, message: string, code = 1, status = 400) {
  return res.status(status).json({ code, message, data: null })
}

export function pageData<T>(
  list: T[],
  total: number,
  page: number,
  pageSize: number,
) {
  return {
    list,
    total,
    page,
    page_size: pageSize,
    total_pages: Math.max(1, Math.ceil(total / pageSize)),
  }
}
