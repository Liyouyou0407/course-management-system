<template>
  <div class="home page-container">
    <HeroBanner :user-name="userName" @cta="goMyLearning" />

    <section class="home__stats">
      <StatCard :value="stats.totalCourses" label="总课程" desc="继续探索新课程吧" tone="blue">
        <template #icon>
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M4 6.5A2.5 2.5 0 016.5 4H20v14H6.5A2.5 2.5 0 004 15.5v-9z" stroke="currentColor" stroke-width="1.8"/>
            <path d="M8 9h8M8 13h5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
          </svg>
        </template>
      </StatCard>
      <StatCard :value="stats.completed" label="已完成" desc="继续保持学习进度" tone="green">
        <template #icon>
          <svg viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="8" stroke="currentColor" stroke-width="1.8"/>
            <path d="M8.5 12.2l2.4 2.4 4.6-4.8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </template>
      </StatCard>
      <StatCard :value="stats.inProgress" label="进行中" desc="正在学习的课程" tone="mint">
        <template #icon>
          <svg viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="8" stroke="currentColor" stroke-width="1.8"/>
            <path d="M12 8v4.5l3 1.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
          </svg>
        </template>
      </StatCard>
      <StatCard :value="`${stats.totalHours}h`" label="总学时(h)" desc="累计学习时长" tone="sky">
        <template #icon>
          <svg viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="8" stroke="currentColor" stroke-width="1.8"/>
            <path d="M12 7v5l3.5 2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
          </svg>
        </template>
      </StatCard>
    </section>

    <section class="home__recommend">
      <div class="home__section-head">
        <h2>推荐课程</h2>
        <button type="button" class="home__more" @click="goCourseCenter">查看更多 &gt;</button>
      </div>
      <p v-if="error" class="home__error">{{ error }}</p>
      <div class="home__grid">
        <CourseCard
          v-for="course in recommended"
          :key="course.id"
          :course="course"
          variant="home"
          @click="goDetail(course.id)"
          @toggle-favorite="onToggleFavorite"
        />
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { storeToRefs } from 'pinia'
import HeroBanner from '@/components/home/HeroBanner.vue'
import StatCard from '@/components/home/StatCard.vue'
import CourseCard from '@/components/course/CourseCard.vue'
import { fetchHomeStats, fetchRecommended } from '@/api/courses'
import { toggleFavorite } from '@/api/favorites'
import { useUserStore } from '@/stores/user'
import type { Course, HomeStats } from '@/types/course'

const router = useRouter()
const { user } = storeToRefs(useUserStore())

const userName = computed(() => user.value?.name || '学员')
const stats = ref<HomeStats>({
  totalCourses: 0,
  completed: 0,
  inProgress: 0,
  totalHours: 0,
})
const recommended = ref<Course[]>([])
const error = ref('')

onMounted(async () => {
  try {
    const [s, list] = await Promise.all([fetchHomeStats(), fetchRecommended()])
    stats.value = s
    recommended.value = list
  } catch (e) {
    error.value = e instanceof Error ? e.message : '加载失败'
  }
})

function goMyLearning() {
  router.push({ name: 'my-learning' })
}

function goCourseCenter() {
  router.push({ name: 'courses' })
}

function goDetail(id: number) {
  router.push({ name: 'course-detail', params: { id: String(id) } })
}

async function onToggleFavorite(course: Course) {
  const prev = course.isFavorited
  try {
    const res = await toggleFavorite(course.id, prev)
    course.isFavorited = res.favorited
  } catch (e) {
    error.value = e instanceof Error ? e.message : '收藏操作失败'
  }
}
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.home {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.home__stats {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;

  @include tablet {
    grid-template-columns: repeat(2, 1fr);
  }

  @include mobile {
    grid-template-columns: repeat(2, 1fr);
  }
}

.home__section-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;

  h2 {
    font-size: 18px;
    font-weight: 700;
    color: $text-title;
  }
}

.home__more {
  border: none;
  background: transparent;
  padding: 0;
  font-size: 13px;
  color: $text-secondary;
  cursor: pointer;

  &:hover {
    color: $primary;
  }
}

.home__error {
  color: #ef4444;
  font-size: 13px;
  margin-bottom: 12px;
}

.home__grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;

  @include tablet {
    grid-template-columns: repeat(2, 1fr);
  }

  @include mobile {
    grid-template-columns: 1fr;
  }
}
</style>
