<template>
  <article class="course-card" :class="{ 'is-home': variant === 'home' }" @click="$emit('click')">
    <div class="course-cover" :class="coverTheme">
      <span class="course-cover__badge">{{ coverBadge }}</span>
      <div class="cover-lines" aria-hidden="true" />
      <b class="course-cover__brand">
        凡岛大学
        <br />
        COURSE
      </b>
      <button
        type="button"
        class="course-cover__fav"
        :class="{ on: course.isFavorited }"
        :aria-label="course.isFavorited ? '取消收藏' : '收藏课程'"
        @click.stop="$emit('toggle-favorite', course)"
      >
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path
            d="M12 20s-7-4.35-7-10a4 4 0 017-2.65A4 4 0 0119 10c0 5.65-7 10-7 10z"
            :fill="course.isFavorited ? 'currentColor' : 'none'"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linejoin="round"
          />
        </svg>
      </button>
      <button
        type="button"
        class="course-cover__go"
        aria-label="查看课程"
        @click.stop="$emit('click')"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M5 12h14" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" />
          <path
            d="m13 6 6 6-6 6"
            stroke="currentColor"
            stroke-width="1.8"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </button>
    </div>

    <div class="course-body">
      <div class="course-tags">
        <span>{{ primaryTag }}</span>
        <i>{{ secondaryTag }}</i>
      </div>
      <h3>{{ course.title }}</h3>
      <p>{{ metaLine }}</p>
      <div class="course-meta">
        <span>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="12" cy="8" r="4" stroke="currentColor" stroke-width="1.8" />
            <path d="M4 21a8 8 0 0 1 16 0" stroke="currentColor" stroke-width="1.8" />
          </svg>
          {{ course.lecturerName }}
        </span>
        <span v-if="course.ratingCount > 0 && ratingText" class="rating">★ {{ ratingText }}</span>
        <span>{{ course.studentCount }}人报名</span>
        <span v-if="variant === 'home'" class="status" :class="course.statusLabel">
          {{ statusText }}
        </span>
      </div>
      <div v-if="variant === 'center'" class="course-actions">
        <button
          type="button"
          class="enroll-btn"
          :class="{ enrolled: course.isEnrolled }"
          @click.stop="$emit('enroll', course)"
        >
          {{ course.isEnrolled ? '已报名' : '立即报名' }}
        </button>
      </div>
    </div>
  </article>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { Course } from '@/types/course'
import { resolveCoverTheme } from '@/utils/coverTheme'

const props = withDefaults(
  defineProps<{
    course: Course
    variant?: 'home' | 'center'
  }>(),
  { variant: 'home' },
)

defineEmits<{
  click: []
  enroll: [course: Course]
  'toggle-favorite': [course: Course]
}>()

const coverTheme = computed(() =>
  resolveCoverTheme({
    id: props.course.id,
    isHot: props.course.isHot,
    isNew: props.course.isNew,
  }),
)

const coverBadge = computed(() => {
  if (props.course.isHot) return '热门课程'
  if (props.course.isNew) return '最新上架'
  if (props.course.isLive) return '直播课'
  return '精品课程'
})

const primaryTag = computed(() => {
  if (props.course.isHot) return '热门'
  if (props.course.isNew) return '最新'
  return '精品课程'
})

const secondaryTag = computed(() => {
  return props.course.departmentName || (props.course.isLive ? '直播课' : '凡岛大学')
})

const metaLine = computed(() => {
  const { plannedDate, weekday, startTime, endTime } = props.course
  return `${plannedDate}(${weekday}) · ${startTime}-${endTime}`
})

const statusText = computed(() => {
  if (props.course.statusLabel === 'learning') return '学习中'
  if (props.course.statusLabel === 'completed') return '已完成'
  return '报名中'
})

const ratingText = computed(() => {
  const n =
    typeof props.course.ratingAvg === 'number'
      ? props.course.ratingAvg
      : Number(props.course.ratingAvg)
  return Number.isFinite(n) ? n.toFixed(1) : ''
})
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;
@use '@/styles/course-cover.scss' as cover;

.course-card {
  cursor: pointer;
  background: #fff;
  border: 1px solid #e1e9f2;
  border-radius: 15px;
  overflow: hidden;
  transition: box-shadow 0.25s ease, transform 0.25s ease;

  &:hover {
    box-shadow: 0 18px 60px rgba(29, 71, 126, 0.1);
    transform: translateY(-4px);
  }
}

.course-cover {
  @include cover.course-cover-base;
  height: 140px;
  padding: 14px;
}

.course-cover__badge {
  @include cover.course-cover-badge;
}

.cover-lines {
  @include cover.course-cover-lines;
}

.course-cover__brand {
  @include cover.course-cover-brand;
}

.course-cover__fav {
  position: absolute;
  top: 12px;
  right: 12px;
  z-index: 3;
  width: 32px;
  height: 32px;
  border: 1px solid rgba(255, 255, 255, 0.35);
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.14);
  color: #fff;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  backdrop-filter: blur(8px);
  transition: transform 0.15s ease, background 0.15s ease;

  svg {
    width: 16px;
    height: 16px;
  }

  &:hover {
    transform: scale(1.05);
    background: rgba(255, 255, 255, 0.22);
  }

  &.on {
    color: #ff8a8a;
  }
}

.course-cover__go {
  position: absolute;
  right: 16px;
  bottom: 14px;
  z-index: 3;
  width: 36px;
  height: 36px;
  border: 1px solid rgba(255, 255, 255, 0.5);
  border-radius: 50%;
  color: #fff;
  background: rgba(255, 255, 255, 0.14);
  backdrop-filter: blur(8px);
  display: grid;
  place-items: center;
  cursor: pointer;
  transition: background 0.15s ease;

  &:hover {
    background: rgba(255, 255, 255, 0.24);
  }
}

.course-body {
  padding: 18px 18px 16px;
}

.course-tags {
  display: flex;
  align-items: center;
  gap: 7px;

  span,
  i {
    border-radius: 4px;
    padding: 4px 7px;
    font-size: 11px;
    font-weight: 650;
    font-style: normal;
    line-height: 1;
  }

  span {
    color: #2369bd;
    background: #eaf3ff;
  }

  i {
    color: #68788b;
    background: #f1f4f7;
  }
}

.course-body h3 {
  margin: 10px 0 4px;
  font-size: 17px;
  font-weight: 750;
  line-height: 1.35;
  color: $text-title;
  @include text-ellipsis(2);
}

.course-body > p {
  margin: 0 0 10px;
  font-size: 13px;
  font-weight: 500;
  line-height: 1.4;
  color: #8090a2;
}

.course-card.is-home {
  .course-cover {
    height: 108px;
    padding: 12px;
  }

  .course-cover__brand {
    font-size: 12px;
    left: 12px;
    bottom: 12px;
  }

  .course-cover__go {
    width: 30px;
    height: 30px;
    right: 12px;
    bottom: 10px;
  }

  .course-body {
    padding: 12px 14px 12px;
  }

  .course-body h3 {
    margin: 8px 0 2px;
    font-size: 15px;
    min-height: 0;
  }

  .course-body > p {
    margin: 0 0 8px;
    font-size: 12px;
  }

  .course-meta {
    gap: 8px 10px;
  }
}

.course-meta {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px 12px;
  font-size: 12px;
  font-weight: 500;
  color: #8896a7;

  span {
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }

  .rating {
    color: #e9992c;
  }

  .status {
    margin-left: auto;
    font-weight: 600;

    &.enrolling {
      color: $success;
    }

    &.learning {
      color: $primary;
    }

    &.completed {
      color: $text-muted;
    }
  }
}

.course-actions {
  margin-top: 14px;
  display: flex;
  justify-content: flex-end;
}

.enroll-btn {
  height: 32px;
  padding: 0 14px;
  border-radius: 8px;
  border: 1px solid $primary;
  background: $primary;
  color: #fff;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.15s ease, color 0.15s ease;

  &:hover {
    background: $primary-hover;
    border-color: $primary-hover;
  }

  &.enrolled {
    background: #fff;
    color: $primary;
  }
}
</style>
