import type { Course, Department, Enrollment, Evaluation, Favorite, LearningProgress } from '@prisma/client'
import { prisma } from './prisma'

type CourseWithDept = Course & { department: Department | null }

export async function getRatingMap(courseIds: number[]) {
  if (courseIds.length === 0) return new Map<number, { avg: number | null; count: number }>()
  const rows = await prisma.evaluation.groupBy({
    by: ['courseId'],
    where: { courseId: { in: courseIds } },
    _avg: { avgScore: true },
    _count: { _all: true },
  })
  const map = new Map<number, { avg: number | null; count: number }>()
  for (const id of courseIds) map.set(id, { avg: null, count: 0 })
  for (const row of rows) {
    map.set(row.courseId, {
      avg: row._avg.avgScore == null ? null : Math.round(row._avg.avgScore * 10) / 10,
      count: row._count._all,
    })
  }
  return map
}

export async function getStudentCountMap(courseIds: number[]) {
  const map = new Map<number, number>()
  for (const id of courseIds) map.set(id, 0)
  if (courseIds.length === 0) return map
  const rows = await prisma.enrollment.groupBy({
    by: ['courseId'],
    where: { courseId: { in: courseIds }, status: 'approved' },
    _count: { _all: true },
  })
  for (const row of rows) map.set(row.courseId, row._count._all)
  return map
}

export function mapCourse(
  course: CourseWithDept,
  extras: {
    studentCount: number
    ratingAvg: number | null
    ratingCount: number
    isFavorited: boolean
    isEnrolled: boolean
    statusLabel?: 'enrolling' | 'learning' | 'completed' | 'not_started'
  },
) {
  return {
    id: course.id,
    title: course.title,
    coverGradient: course.coverGradient,
    lecturerName: course.lecturerName,
    plannedDate: course.plannedDate,
    weekday: course.weekday,
    startTime: course.startTime,
    endTime: course.endTime,
    location: course.location,
    departmentName: course.department?.name || '',
    studentCount: extras.studentCount,
    isHot: course.isHot,
    isNew: course.isNew,
    isLive: course.isLive,
    isFavorited: extras.isFavorited,
    isEnrolled: extras.isEnrolled,
    statusLabel: extras.statusLabel || (extras.isEnrolled ? 'learning' : 'enrolling'),
    ratingAvg: extras.ratingAvg,
    ratingCount: extras.ratingCount,
  }
}

export function formatDate(d: Date | null | undefined) {
  if (!d) return null
  return d.toISOString().slice(0, 10)
}

export function mapMyCourse(
  enrollment: Enrollment & {
    course: CourseWithDept
  },
  progress: LearningProgress | null,
  myEval: Evaluation | null,
  ratingAvg: number | null,
  ratingCount: number,
) {
  const percent = progress?.progressPercent ?? 0
  let learnStatus: 'in_progress' | 'not_started' | 'completed' = 'not_started'
  if (percent >= 100) learnStatus = 'completed'
  else if (percent > 0) learnStatus = 'in_progress'

  return {
    id: enrollment.id,
    courseId: enrollment.courseId,
    courseTitle: enrollment.course.title,
    coverGradient: enrollment.course.coverGradient,
    lecturerName: enrollment.course.lecturerName,
    plannedDate: enrollment.course.plannedDate,
    weekday: enrollment.course.weekday,
    startTime: enrollment.course.startTime,
    endTime: enrollment.course.endTime,
    location: enrollment.course.location,
    departmentName: enrollment.course.department?.name || '',
    tag: learnStatus === 'not_started' ? 'upcoming' : 'live',
    learnStatus,
    progressPercent: percent,
    lastStudyAt: formatDate(progress?.lastStudyAt),
    startDate:
      learnStatus === 'not_started'
        ? `2026-${enrollment.course.plannedDate} ${enrollment.course.startTime}`
        : null,
    completedAt: formatDate(progress?.completedAt),
    score: myEval?.avgScore ?? null,
    canEvaluate: learnStatus === 'completed' && !myEval,
    myRating: myEval?.avgScore ?? null,
    ratingAvg,
    ratingCount,
  }
}

export type { Favorite }
