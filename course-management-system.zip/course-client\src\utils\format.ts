export function formatStudentCount(count: number): string {
  return `${count}人报名`
}

export function formatDateTime(date: string, weekday: string, start: string, end: string): string {
  return `${date}(${weekday}) ${start}-${end}`
}

export function formatPageTotal(total: number): string {
  return `共 ${total} 条`
}
