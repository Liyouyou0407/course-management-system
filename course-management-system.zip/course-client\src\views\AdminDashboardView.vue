<template>
  <div class="dash page-container">
    <p v-if="error" class="dash__error">{{ error }}</p>

    <div class="dash__metrics">
      <AdminMetricCard
        :value="stats.totalCourses"
        label="总课程"
        desc="较上月新增课程"
        :delta="stats.deltas.totalCourses"
        tone="blue"
      >
        <template #icon>
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M4 6.5A2.5 2.5 0 016.5 4H20v14H6.5A2.5 2.5 0 004 15.5v-9z" stroke="currentColor" stroke-width="1.6" />
            <path d="M8 8h8M8 12h5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" />
          </svg>
        </template>
      </AdminMetricCard>
      <AdminMetricCard
        :value="stats.totalStudents"
        label="总学员"
        desc="平台注册学员"
        :delta="stats.deltas.totalStudents"
        tone="green"
      >
        <template #icon>
          <svg viewBox="0 0 24 24" fill="none">
            <circle cx="9" cy="9" r="3" stroke="currentColor" stroke-width="1.6" />
            <path d="M4 18c.8-2.5 2.8-3.8 5-3.8S13.2 15.5 14 18" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" />
            <circle cx="16.5" cy="9.5" r="2.2" stroke="currentColor" stroke-width="1.4" />
          </svg>
        </template>
      </AdminMetricCard>
      <AdminMetricCard
        :value="stats.inProgressCourses"
        label="进行中课程"
        desc="有学员正在学习"
        :delta="stats.deltas.inProgressCourses"
        tone="purple"
      >
        <template #icon>
          <svg viewBox="0 0 24 24" fill="none">
            <rect x="5" y="4" width="14" height="16" rx="2" stroke="currentColor" stroke-width="1.6" />
            <path d="M9 9h6M9 13h4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" />
          </svg>
        </template>
      </AdminMetricCard>
      <AdminMetricCard
        :value="`${stats.completionRate}%`"
        label="课程完成率"
        desc="已完成 / 有进度课程"
        :delta="stats.deltas.completionRate"
        delta-suffix="%"
        tone="orange"
      >
        <template #icon>
          <svg viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="8" stroke="currentColor" stroke-width="1.6" />
            <path d="M8.5 12.5l2.5 2.5 4.5-5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" />
          </svg>
        </template>
      </AdminMetricCard>
    </div>

    <div class="dash__grid">
      <section class="panel trend">
        <div class="panel__head">
          <h2>课程报名趋势</h2>
          <select v-model.number="trendMonths" class="panel__select">
            <option :value="6">近6个月</option>
            <option :value="3">近3个月</option>
          </select>
        </div>
        <div class="trend__chart">
          <svg viewBox="0 0 560 200" preserveAspectRatio="none">
            <polyline
              v-if="polyline"
              :points="polyline"
              fill="none"
              stroke="#2D5BFF"
              stroke-width="2.5"
              stroke-linejoin="round"
              stroke-linecap="round"
            />
            <circle
              v-for="(p, i) in chartPoints"
              :key="i"
              :cx="p.x"
              :cy="p.y"
              r="4"
              fill="#fff"
              stroke="#2D5BFF"
              stroke-width="2"
            />
          </svg>
          <div class="trend__labels">
            <span v-for="p in trendPoints" :key="p.label">{{ p.label }}</span>
          </div>
        </div>
      </section>

      <section class="panel activities">
        <div class="panel__head">
          <h2>最新动态</h2>
        </div>
        <ul class="activities__list">
          <li v-for="item in activities" :key="item.id">
            <span class="dot" :class="item.type" />
            <div>
              <p>{{ item.text }}</p>
              <time>{{ item.timeLabel }}</time>
            </div>
          </li>
          <li v-if="activities.length === 0" class="empty">暂无动态</li>
        </ul>
      </section>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import AdminMetricCard from '@/components/admin/AdminMetricCard.vue'
import { fetchAdminActivities, fetchAdminStats, fetchEnrollmentTrend } from '@/api/admin'
import type { AdminActivity, AdminStats, AdminTrendPoint } from '@/types/course'

const error = ref('')
const trendMonths = ref(6)
const trendPoints = ref<AdminTrendPoint[]>([])
const activities = ref<AdminActivity[]>([])

const stats = ref<AdminStats>({
  totalCourses: 0,
  totalStudents: 0,
  inProgressCourses: 0,
  completionRate: 0,
  published: 0,
  draft: 0,
  archived: 0,
  enrollments: 0,
  evaluations: 0,
  deltas: {
    totalCourses: 0,
    totalStudents: 0,
    inProgressCourses: 0,
    completionRate: 0,
  },
})

const chartPoints = computed(() => {
  const pts = trendPoints.value
  if (!pts.length) return []
  const max = Math.max(...pts.map((p) => p.value), 1)
  const w = 560
  const h = 200
  const padX = 24
  const padTop = 48
  const padBottom = 28
  return pts.map((p, i) => {
    const x = padX + (i * (w - padX * 2)) / Math.max(pts.length - 1, 1)
    const y = padTop + (1 - p.value / max) * (h - padTop - padBottom)
    return { x, y }
  })
})

const polyline = computed(() => chartPoints.value.map((p) => `${p.x},${p.y}`).join(' '))

async function loadTrend() {
  const data = await fetchEnrollmentTrend(trendMonths.value)
  trendPoints.value = data.points
}

onMounted(async () => {
  try {
    const [s, a] = await Promise.all([fetchAdminStats(), fetchAdminActivities(10)])
    stats.value = s
    activities.value = a
    await loadTrend()
  } catch (e) {
    error.value = e instanceof Error ? e.message : '加载失败'
  }
})

watch(trendMonths, () => {
  loadTrend().catch((e) => {
    error.value = e instanceof Error ? e.message : '趋势加载失败'
  })
})
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.dash {
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.dash__error {
  color: #ef4444;
  font-size: 13px;
}

.dash__metrics {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 18px;
  flex-shrink: 0;

  :deep(.metric) {
    padding: 26px 26px;
    min-height: 132px;
  }

  :deep(.metric__value) {
    font-size: 32px;
  }

  :deep(.metric__icon) {
    width: 52px;
    height: 52px;
  }

  @media (max-width: 1100px) {
    grid-template-columns: 1fr 1fr;
  }

  @include mobile {
    grid-template-columns: 1fr;
  }
}

.dash__grid {
  display: grid;
  grid-template-columns: 1.35fr 1fr;
  gap: 18px;
  align-items: stretch;

  @media (max-width: 1100px) {
    grid-template-columns: 1fr;
  }
}

.panel {
  @include card;
  background: #fff;
  padding: 18px 20px;
  display: flex;
  flex-direction: column;
  min-height: 360px;
  max-height: 460px;
}

.panel__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 14px;
  flex-shrink: 0;

  h2 {
    font-size: 15px;
    font-weight: 600;
    color: $text-title;
  }
}

.panel__select {
  height: 30px;
  border: 1px solid $border;
  border-radius: 6px;
  padding: 0 8px;
  font-size: 12px;
  color: $text-secondary;
  background: #fff;
}

.trend__chart {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  min-height: 0;
  padding-top: 12px;

  svg {
    width: 100%;
    height: 220px;
    display: block;
    margin-top: auto;
  }
}

.trend__labels {
  display: flex;
  justify-content: space-between;
  padding: 18px 8px 4px;
  font-size: 12px;
  color: $text-muted;
}

.activities__list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 14px;
  flex: 1;
  overflow: auto;
  min-height: 0;

  li {
    display: flex;
    gap: 10px;
    align-items: flex-start;
  }

  p {
    font-size: 13px;
    color: $text-body;
    line-height: 1.4;
  }

  time {
    display: block;
    margin-top: 4px;
    font-size: 12px;
    color: $text-muted;
  }
}

.dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-top: 6px;
  flex-shrink: 0;
  background: $primary;

  &.complete {
    background: $success;
  }
}

.empty {
  font-size: 13px;
  color: $text-muted;
}
</style>
