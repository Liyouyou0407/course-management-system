import { Router } from 'express'
import bcrypt from 'bcryptjs'
import { z } from 'zod'
import { prisma } from '../lib/prisma'
import { fail, ok } from '../lib/response'
import { publicUser } from '../lib/roles'
import { authRequired, signToken, type AuthRequest } from '../middleware/auth'

const router = Router()

router.post('/login', async (req, res) => {
  const schema = z.object({
    username: z.string().min(1),
    password: z.string().min(1),
  })
  const parsed = schema.safeParse(req.body)
  if (!parsed.success) return fail(res, '请输入账号和密码')

  const user = await prisma.user.findUnique({
    where: { username: parsed.data.username },
    include: { department: true },
  })
  if (!user || user.status !== 1) return fail(res, '账号或密码错误', 401, 401)

  const match = await bcrypt.compare(parsed.data.password, user.passwordHash)
  if (!match) return fail(res, '账号或密码错误', 401, 401)

  const token = signToken(user.id)
  return ok(res, {
    token,
    user: publicUser(user),
  })
})

router.get('/me', authRequired, async (req: AuthRequest, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.userId! },
    include: { department: true },
  })
  if (!user) return fail(res, '用户不存在', 404, 404)
  return ok(res, publicUser(user))
})

export default router
