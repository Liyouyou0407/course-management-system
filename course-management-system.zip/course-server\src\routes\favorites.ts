import { Router } from 'express'
import { prisma } from '../lib/prisma'
import { fail, ok } from '../lib/response'
import { authRequired, type AuthRequest } from '../middleware/auth'

const router = Router()

router.post('/:courseId', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const courseId = Number(req.params.courseId)
  if (!courseId) return fail(res, '课程 ID 无效')

  const course = await prisma.course.findUnique({ where: { id: courseId } })
  if (!course) return fail(res, '课程不存在', 404, 404)

  await prisma.favorite.upsert({
    where: { userId_courseId: { userId, courseId } },
    create: { userId, courseId },
    update: {},
  })
  return ok(res, { course_id: courseId, favorited: true })
})

router.delete('/:courseId', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const courseId = Number(req.params.courseId)
  await prisma.favorite.deleteMany({ where: { userId, courseId } })
  return ok(res, { course_id: courseId, favorited: false })
})

export default router
