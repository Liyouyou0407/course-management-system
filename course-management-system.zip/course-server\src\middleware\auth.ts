import type { NextFunction, Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import { fail } from '../lib/response'

export interface AuthRequest extends Request {
  userId?: number
}

const secret = process.env.JWT_SECRET || 'fandao-course-secret-2026'

export function signToken(userId: number) {
  return jwt.sign({ userId }, secret, { expiresIn: '7d' })
}

export function authRequired(req: AuthRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization
  if (!header?.startsWith('Bearer ')) {
    return fail(res, '未登录', 401, 401)
  }
  try {
    const payload = jwt.verify(header.slice(7), secret) as { userId: number }
    req.userId = payload.userId
    next()
  } catch {
    return fail(res, '登录已过期', 401, 401)
  }
}
