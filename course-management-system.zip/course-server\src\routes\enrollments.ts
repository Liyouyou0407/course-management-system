import { Router } from 'express'
import { prisma } from '../lib/prisma'
import { fail, ok } from '../lib/response'
import { authRequired, type AuthRequest } from '../middleware/auth'

const router = Router()

router.post('/', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const courseId = Number(req.body?.course_id)
  if (!courseId) return fail(res, '缺少 course_id')

  const course = await prisma.course.findUnique({ where: { id: courseId } })
  if (!course) return fail(res, '课程不存在', 404, 404)

  const existing = await prisma.enrollment.findUnique({
    where: { courseId_studentId: { courseId, studentId: userId } },
  })
  if (existing?.status === 'approved') return fail(res, '已报名该课程')

  if (existing) {
    await prisma.enrollment.update({
      where: { id: existing.id },
      data: { status: 'approved', cancelledAt: null, signedUpAt: new Date() },
    })
  } else {
    await prisma.enrollment.create({
      data: { courseId, studentId: userId, status: 'approved' },
    })
  }

  await prisma.learningProgress.upsert({
    where: { userId_courseId: { userId, courseId } },
    create: { userId, courseId, progressPercent: 0 },
    update: {},
  })

  return ok(res, { course_id: courseId, enrolled: true })
})

router.delete('/:courseId', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const courseId = Number(req.params.courseId)
  const existing = await prisma.enrollment.findUnique({
    where: { courseId_studentId: { courseId, studentId: userId } },
  })
  if (!existing) return fail(res, '未报名该课程', 404, 404)

  await prisma.enrollment.update({
    where: { id: existing.id },
    data: { status: 'cancelled', cancelledAt: new Date() },
  })
  return ok(res, { course_id: courseId, enrolled: false })
})

router.get('/check/:courseId', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const courseId = Number(req.params.courseId)
  const existing = await prisma.enrollment.findUnique({
    where: { courseId_studentId: { courseId, studentId: userId } },
  })
  return ok(res, { enrolled: existing?.status === 'approved' })
})

export default router
