import { request } from './request'

export function enrollCourse(courseId: number) {
  return request<{ course_id: number; enrolled: boolean }>('/enrollments', {
    method: 'POST',
    body: JSON.stringify({ course_id: courseId }),
  })
}

export function cancelEnrollment(courseId: number) {
  return request<{ course_id: number; enrolled: boolean }>(`/enrollments/${courseId}`, {
    method: 'DELETE',
  })
}
