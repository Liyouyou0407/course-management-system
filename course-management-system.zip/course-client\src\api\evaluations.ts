import { request } from './request'

export interface EvaluationPayload {
  course_id: number
  score_experience: number
  score_fluency: number
  score_practicality: number
  score_inspiration: number
  feedback?: string
}

export function submitEvaluation(payload: EvaluationPayload) {
  return request<{ course_id: number; avg_score: number }>('/evaluations', {
    method: 'POST',
    body: JSON.stringify(payload),
  })
}

export function fetchMyEvaluation(courseId: number) {
  return request<{
    course_id: number
    avg_score: number
    feedback: string | null
  } | null>(`/evaluations/mine/${courseId}`)
}
