<template>
  <article class="my-course">
    <div class="my-course__cover" :style="{ background: course.coverGradient }">
      <StatusBadge
        :label="course.tag === 'upcoming' ? '未开始' : '直播课'"
        :type="course.tag === 'upcoming' ? 'warning' : 'live'"
        class="my-course__tag"
      />
    </div>

    <div class="my-course__main">
      <div class="my-course__header">
        <h3 class="my-course__title">{{ course.courseTitle }}</h3>
        <span class="my-course__badge" :class="course.learnStatus">{{ statusLabel }}</span>
      </div>
      <p class="my-course__row">
        <svg viewBox="0 0 16 16" fill="none"><rect x="2" y="3" width="12" height="11" rx="1.5" stroke="currentColor" stroke-width="1.2"/><path d="M2 6.5h12M5 1.5v3M11 1.5v3" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>
        {{ course.plannedDate }}({{ course.weekday }}) {{ course.startTime }}-{{ course.endTime }}
      </p>
      <p class="my-course__row">
        <svg viewBox="0 0 16 16" fill="none"><path d="M3 11.5V5.5l5-2.5 5 2.5v6l-5 2.5-5-2.5z" stroke="currentColor" stroke-width="1.2"/><path d="M8 3v11M3 5.5l5 2.5 5-2.5" stroke="currentColor" stroke-width="1.2"/></svg>
        {{ course.location }}
      </p>
      <p class="my-course__row">
        <svg viewBox="0 0 16 16" fill="none"><circle cx="8" cy="5.5" r="2.5" stroke="currentColor" stroke-width="1.2"/><path d="M3 13c.8-2.2 2.5-3.3 5-3.3S12.2 10.8 13 13" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>
        讲师：{{ course.lecturerName }}
      </p>
      <p class="my-course__row">
        <svg viewBox="0 0 16 16" fill="none"><path d="M2.5 13V4.5A1.5 1.5 0 014 3h8a1.5 1.5 0 011.5 1.5V13L8 11 2.5 13z" stroke="currentColor" stroke-width="1.2"/></svg>
        所属部门：{{ course.departmentName }}
      </p>
    </div>

    <div class="my-course__aside">
      <template v-if="course.learnStatus === 'in_progress'">
        <div class="aside-label">
          <span>学习进度</span>
          <strong>{{ course.progressPercent }}%</strong>
        </div>
        <ProgressBar :percent="course.progressPercent" />
        <p class="aside-meta">上次学习：{{ course.lastStudyAt }}</p>
        <button type="button" class="btn btn-primary" @click="$emit('continue', course)">
          继续学习
        </button>
      </template>

      <template v-else-if="course.learnStatus === 'not_started'">
        <p class="aside-label soft">开始时间</p>
        <p class="aside-time">{{ course.startDate }}</p>
        <button type="button" class="btn btn-outline" @click="$emit('detail', course)">
          查看详情
        </button>
      </template>

      <template v-else>
        <p class="aside-label soft">完成日期</p>
        <p class="aside-time">{{ course.completedAt }}</p>
        <template v-if="course.canEvaluate">
          <p class="aside-eval-hint">完成学习后可进行四维评分</p>
          <button type="button" class="btn btn-primary aside-eval-btn" @click="$emit('evaluate', course)">
            去评价
          </button>
        </template>
        <template v-else>
          <p v-if="ratedText" class="aside-meta">已评价 ⭐ {{ ratedText }}</p>
          <button type="button" class="btn btn-outline" @click="$emit('detail', course)">
            查看详情
          </button>
        </template>
      </template>
    </div>
  </article>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { MyCourse } from '@/types/course'
import StatusBadge from '@/components/common/StatusBadge.vue'
import ProgressBar from '@/components/common/ProgressBar.vue'

const props = defineProps<{ course: MyCourse }>()

defineEmits<{
  continue: [course: MyCourse]
  detail: [course: MyCourse]
  evaluate: [course: MyCourse]
}>()

const statusLabel = computed(() => {
  const map = {
    in_progress: '进行中',
    not_started: '未开始',
    completed: '已完成',
  }
  return map[props.course.learnStatus]
})

const ratedText = computed(() => {
  const raw = props.course.myRating ?? props.course.score
  if (raw == null) return ''
  const n = typeof raw === 'number' ? raw : Number(raw)
  return Number.isFinite(n) ? n.toFixed(1) : ''
})
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.my-course {
  @include card;
  display: grid;
  grid-template-columns: 180px 1fr 200px;
  gap: 20px;
  padding: 16px;
  background: #fff;
  align-items: stretch;

  @include mobile {
    grid-template-columns: 1fr;
  }
}

.my-course__cover {
  position: relative;
  min-height: 120px;
  border-radius: 8px;
  overflow: hidden;
}

.my-course__tag {
  position: absolute;
  top: 8px;
  left: 8px;
}

.my-course__main {
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
}

.my-course__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 4px;
}

.my-course__title {
  font-size: 16px;
  font-weight: 600;
  color: $text-title;
  line-height: 1.4;
}

.my-course__badge {
  flex-shrink: 0;
  height: 24px;
  padding: 0 10px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  display: inline-flex;
  align-items: center;

  &.in_progress {
    background: $success-soft;
    color: $success;
  }

  &.not_started {
    background: $warning-soft;
    color: $warning;
  }

  &.completed {
    background: #f3f4f6;
    color: $text-secondary;
  }
}

.my-course__row {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: $text-secondary;

  svg {
    width: 14px;
    height: 14px;
    color: $text-muted;
    flex-shrink: 0;
  }
}

.my-course__aside {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 10px;
  padding-left: 8px;
  border-left: 1px solid #f0f2f7;

  @include mobile {
    border-left: none;
    border-top: 1px solid #f0f2f7;
    padding-left: 0;
    padding-top: 12px;
  }

  .btn {
    width: 100%;
  }
}

.aside-label {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13px;
  color: $text-secondary;

  strong {
    color: $primary;
    font-size: 16px;
  }

  &.soft {
    color: $text-muted;
  }
}

.aside-time {
  font-size: 18px;
  font-weight: 600;
  color: $text-title;
  line-height: 1.3;
}

.aside-meta {
  font-size: 12px;
  color: $text-muted;
}

.aside-eval-hint {
  font-size: 12px;
  color: #d97706;
  line-height: 1.4;
}

.aside-eval-btn {
  box-shadow: 0 4px 12px rgba(45, 91, 255, 0.28);
}
</style>
