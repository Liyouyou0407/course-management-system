# course-server

凡岛大学课程管理系统 API（学员端 + 管理端，Express + Prisma + SQLite）

## 启动

```bash
npm install
npx prisma db push
npm run db:seed
npm run dev
```

服务地址：`http://localhost:8080`

| 账号 | 密码 | 说明 |
|------|------|------|
| `lifengyun` | `123456` | dept_admin，可切换管理端 |
| `demo` | `123456` | 纯学员 |

## 说明

- 本地使用 SQLite（`prisma/dev.db`），便于零配置运行
- 已含认证、课程、报名、收藏、评价、通知、管理端接口
- 生产可改 `DATABASE_URL` 切换 MySQL
