<template>
  <div class="layout">
    <AppNavbar />
    <main class="layout__main">
      <RouterView />
    </main>
    <AppFooter />
    <MobileTabBar />
  </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import AppNavbar from '@/components/layout/AppNavbar.vue'
import AppFooter from '@/components/layout/AppFooter.vue'
import MobileTabBar from '@/components/layout/MobileTabBar.vue'
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()

onMounted(() => {
  userStore.fetchMe()
})
</script>

<style scoped lang="scss">
.layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.layout__main {
  flex: 1;
  padding: 24px 0 8px;
}
</style>
