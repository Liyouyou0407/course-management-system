import { request } from './request'
import type { Course, CourseCategory, HomeStats, PageResult } from '@/types/course'

export function fetchHomeStats() {
  return request<HomeStats>('/home/stats')
}

export function fetchRecommended() {
  return request<Course[]>('/home/recommended')
}

export function fetchDepartments() {
  return request<{ id: number; name: string }[]>('/home/departments')
}

export function fetchCourses(params: {
  page?: number
  page_size?: number
  keyword?: string
  category?: CourseCategory
  department_id?: number
}) {
  const q = new URLSearchParams()
  if (params.page) q.set('page', String(params.page))
  if (params.page_size) q.set('page_size', String(params.page_size))
  if (params.keyword) q.set('keyword', params.keyword)
  if (params.category) q.set('category', params.category)
  if (params.department_id) q.set('department_id', String(params.department_id))
  return request<PageResult<Course> & { counts: Record<string, number> }>(
    `/courses?${q.toString()}`,
  )
}

export function fetchCourseDetail(id: number) {
  return request<Course>(`/courses/${id}`)
}
