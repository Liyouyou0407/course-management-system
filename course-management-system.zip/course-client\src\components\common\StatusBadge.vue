<template>
  <span class="status-badge" :class="`is-${type}`">{{ label }}</span>
</template>

<script setup lang="ts">
defineProps<{
  label: string
  type?: 'hot' | 'live' | 'success' | 'primary' | 'warning' | 'muted'
}>()
</script>

<style scoped lang="scss">
.status-badge {
  display: inline-flex;
  align-items: center;
  height: 22px;
  padding: 0 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  line-height: 1;
  color: #fff;
}

.is-hot {
  background: $hot;
}

.is-live,
.is-primary {
  background: $primary;
}

.is-success {
  background: $success;
  color: #fff;
}

.is-warning {
  background: $warning;
}

.is-muted {
  background: #e5e7eb;
  color: $text-secondary;
}
</style>
