import type { NextFunction, Response } from 'express'
import { prisma } from '../lib/prisma'
import { fail } from '../lib/response'
import { isManagerRole } from '../lib/roles'
import type { AuthRequest } from './auth'

/** 需先过 authRequired；校验当前用户是否具备管理端角色 */
export async function managerRequired(req: AuthRequest, res: Response, next: NextFunction) {
  const userId = req.userId
  if (!userId) return fail(res, '未登录', 401, 401)

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { role: true, status: true },
  })
  if (!user || user.status !== 1) return fail(res, '用户不存在', 404, 404)
  if (!isManagerRole(user.role)) return fail(res, '无管理权限', 403, 403)
  next()
}
