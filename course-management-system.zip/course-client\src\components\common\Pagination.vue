<template>
  <div class="pagination">
    <span class="pagination__total">共 {{ total }} 条</span>
    <div class="pagination__controls">
      <button type="button" class="page-btn" :disabled="page <= 1" @click="go(page - 1)">‹</button>
      <template v-for="item in pageItems" :key="String(item)">
        <span v-if="item === '...'" class="page-ellipsis">…</span>
        <button
          v-else
          type="button"
          class="page-btn"
          :class="{ active: item === page }"
          @click="go(item as number)"
        >
          {{ item }}
        </button>
      </template>
      <button
        type="button"
        class="page-btn"
        :disabled="page >= totalPages"
        @click="go(page + 1)"
      >
        ›
      </button>
      <select class="page-size" :value="pageSize" @change="onSizeChange">
        <option v-for="size in pageSizes" :key="size" :value="size">{{ size }} 条/页</option>
      </select>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    total: number
    page: number
    pageSize: number
    pageSizes?: number[]
  }>(),
  {
    pageSizes: () => [8, 10, 12, 20],
  },
)

const emit = defineEmits<{
  'update:page': [value: number]
  'update:pageSize': [value: number]
}>()

const totalPages = computed(() => Math.max(1, Math.ceil(props.total / props.pageSize)))

const pageItems = computed(() => {
  const total = totalPages.value
  const current = props.page
  if (total <= 7) {
    return Array.from({ length: total }, (_, i) => i + 1)
  }
  const items: Array<number | '...'> = [1]
  if (current > 3) items.push('...')
  for (let i = Math.max(2, current - 1); i <= Math.min(total - 1, current + 1); i++) {
    items.push(i)
  }
  if (current < total - 2) items.push('...')
  items.push(total)
  return items
})

function go(p: number) {
  if (p < 1 || p > totalPages.value || p === props.page) return
  emit('update:page', p)
}

function onSizeChange(e: Event) {
  emit('update:pageSize', Number((e.target as HTMLSelectElement).value))
  emit('update:page', 1)
}
</script>

<style scoped lang="scss">
.pagination {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 20px 0 8px;
  flex-wrap: wrap;
}

.pagination__total {
  color: $text-secondary;
  font-size: 13px;
}

.pagination__controls {
  display: flex;
  align-items: center;
  gap: 6px;
}

.page-btn {
  min-width: 32px;
  height: 32px;
  padding: 0 8px;
  border: 1px solid $border;
  border-radius: 6px;
  background: #fff;
  color: $text-body;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.15s ease;

  &:hover:not(:disabled):not(.active) {
    border-color: $primary;
    color: $primary;
  }

  &.active {
    background: $primary;
    border-color: $primary;
    color: #fff;
  }

  &:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }
}

.page-ellipsis {
  width: 24px;
  text-align: center;
  color: $text-muted;
}

.page-size {
  height: 32px;
  margin-left: 8px;
  padding: 0 8px;
  border: 1px solid $border;
  border-radius: 6px;
  background: #fff;
  color: $text-secondary;
  font-size: 13px;
  outline: none;
  cursor: pointer;
}
</style>
