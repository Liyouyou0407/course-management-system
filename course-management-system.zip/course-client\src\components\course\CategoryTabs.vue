<template>
  <div class="category-tabs">
    <button
      v-for="tab in tabs"
      :key="tab.key"
      type="button"
      class="category-tabs__item"
      :class="{ active: tab.key === modelValue }"
      @click="$emit('update:modelValue', tab.key)"
    >
      {{ tab.label }}({{ tab.count }})
    </button>
  </div>
</template>

<script setup lang="ts">
import type { CategoryTab } from '@/types/course'

defineProps<{
  tabs: CategoryTab[]
  modelValue: string
}>()

defineEmits<{
  'update:modelValue': [value: string]
}>()
</script>

<style scoped lang="scss">
.category-tabs {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  overflow-x: auto;
  padding-bottom: 2px;
}

.category-tabs__item {
  height: 34px;
  padding: 0 14px;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: $text-secondary;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  white-space: nowrap;
  transition: background 0.15s ease, color 0.15s ease;

  &:hover {
    color: $primary;
    background: rgba(45, 91, 255, 0.06);
  }

  &.active {
    background: $primary-light;
    color: $primary;
  }
}
</style>
