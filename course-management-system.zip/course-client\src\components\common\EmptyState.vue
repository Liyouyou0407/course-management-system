<template>
  <div class="empty">
    <div class="empty__icon">📭</div>
    <p class="empty__text">{{ text }}</p>
  </div>
</template>

<script setup lang="ts">
withDefaults(defineProps<{ text?: string }>(), {
  text: '暂无数据',
})
</script>

<style scoped lang="scss">
.empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 64px 20px;
  color: $text-muted;
}

.empty__icon {
  font-size: 40px;
  margin-bottom: 12px;
}

.empty__text {
  font-size: 14px;
}
</style>
