import { Router } from 'express'
import { prisma } from '../lib/prisma'
import { getRatingMap, getStudentCountMap, mapCourse } from '../lib/courseMap'
import { fail, ok, pageData } from '../lib/response'
import { authRequired, type AuthRequest } from '../middleware/auth'

const router = Router()

router.get('/', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const page = Math.max(1, Number(req.query.page) || 1)
  const pageSize = Math.max(1, Math.min(50, Number(req.query.page_size) || 10))
  const keyword = String(req.query.keyword || '').trim()
  const category = String(req.query.category || 'all')
  const departmentId = Number(req.query.department_id) || 0

  const where: Record<string, unknown> = { status: 'published' }
  if (keyword) {
    where.OR = [
      { title: { contains: keyword } },
      { lecturerName: { contains: keyword } },
    ]
  }
  if (departmentId) {
    where.departmentId = departmentId
  }
  if (category === 'hot') where.isHot = true
  if (category === 'new') where.isNew = true
  if (category === 'upcoming') {
    // 简化：未报名的即将开课
    const enrolled = await prisma.enrollment.findMany({
      where: { studentId: userId, status: 'approved' },
      select: { courseId: true },
    })
    where.id = { notIn: enrolled.map((e) => e.courseId) }
  }
  if (category === 'favorite') {
    const favs = await prisma.favorite.findMany({
      where: { userId },
      select: { courseId: true },
    })
    where.id = { in: favs.map((f) => f.courseId) }
  }

  const [total, courses, countsMeta] = await Promise.all([
    prisma.course.count({ where }),
    prisma.course.findMany({
      where,
      include: { department: true },
      orderBy: { id: 'asc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    Promise.all([
      prisma.course.count({ where: { status: 'published' } }),
      prisma.course.count({ where: { status: 'published', isNew: true } }),
      prisma.course.count({ where: { status: 'published', isHot: true } }),
      prisma.favorite.count({ where: { userId } }),
    ]),
  ])

  const ids = courses.map((c) => c.id)
  const [ratings, counts, favorites, enrollments] = await Promise.all([
    getRatingMap(ids),
    getStudentCountMap(ids),
    prisma.favorite.findMany({ where: { userId, courseId: { in: ids } } }),
    prisma.enrollment.findMany({
      where: { studentId: userId, courseId: { in: ids }, status: 'approved' },
    }),
  ])
  const favSet = new Set(favorites.map((f) => f.courseId))
  const enrSet = new Set(enrollments.map((e) => e.courseId))

  // upcoming count: published not enrolled
  const enrolledAll = await prisma.enrollment.findMany({
    where: { studentId: userId, status: 'approved' },
    select: { courseId: true },
  })
  const upcomingCount = await prisma.course.count({
    where: {
      status: 'published',
      id: { notIn: enrolledAll.map((e) => e.courseId) },
    },
  })

  const list = courses.map((c) => {
    const rating = ratings.get(c.id)!
    return mapCourse(c, {
      studentCount: counts.get(c.id) || 0,
      ratingAvg: rating.avg,
      ratingCount: rating.count,
      isFavorited: favSet.has(c.id),
      isEnrolled: enrSet.has(c.id),
    })
  })

  return ok(res, {
    ...pageData(list, total, page, pageSize),
    counts: {
      all: countsMeta[0],
      new: countsMeta[1],
      hot: countsMeta[2],
      upcoming: upcomingCount,
      favorite: countsMeta[3],
    },
  })
})

router.get('/:id', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const id = Number(req.params.id)
  const course = await prisma.course.findUnique({
    where: { id },
    include: { department: true },
  })
  if (!course) return fail(res, '课程不存在', 404, 404)

  const [ratings, counts, fav, enr, progress, myEval] = await Promise.all([
    getRatingMap([id]),
    getStudentCountMap([id]),
    prisma.favorite.findUnique({
      where: { userId_courseId: { userId, courseId: id } },
    }),
    prisma.enrollment.findUnique({
      where: { courseId_studentId: { courseId: id, studentId: userId } },
    }),
    prisma.learningProgress.findUnique({
      where: { userId_courseId: { userId, courseId: id } },
    }),
    prisma.evaluation.findUnique({
      where: { courseId_studentId: { courseId: id, studentId: userId } },
    }),
  ])
  const rating = ratings.get(id)!
  const enrolled = enr?.status === 'approved'
  const completed = (progress?.progressPercent ?? 0) >= 100
  const mapped = mapCourse(course, {
    studentCount: counts.get(id) || 0,
    ratingAvg: rating.avg,
    ratingCount: rating.count,
    isFavorited: !!fav,
    isEnrolled: enrolled,
  })
  return ok(res, {
    ...mapped,
    canEvaluate: enrolled && completed && !myEval,
    myRating: myEval?.avgScore ?? null,
  })
})

router.get('/:id/evaluation-stats', authRequired, async (req, res) => {
  const id = Number(req.params.id)
  const ratings = await getRatingMap([id])
  const rating = ratings.get(id)!
  const list = await prisma.evaluation.findMany({
    where: { courseId: id },
    select: {
      scoreExperience: true,
      scoreFluency: true,
      scorePracticality: true,
      scoreInspiration: true,
    },
  })
  const avg = (key: keyof (typeof list)[0]) =>
    list.length
      ? Math.round((list.reduce((s, i) => s + i[key], 0) / list.length) * 10) / 10
      : null

  return ok(res, {
    rating_avg: rating.avg,
    rating_count: rating.count,
    dimensions: {
      experience: avg('scoreExperience'),
      fluency: avg('scoreFluency'),
      practicality: avg('scorePracticality'),
      inspiration: avg('scoreInspiration'),
    },
  })
})

export default router
