<template>
  <header class="navbar">
    <div class="navbar__inner page-container">
      <RouterLink :to="brandTo" class="navbar__brand">
        <img class="navbar__logo-img" src="/fandow-logo.png" alt="Fandow" />
        <span class="navbar__title">凡岛大学·课程管理系统</span>
        <span v-if="variant === 'admin'" class="navbar__badge">管理端</span>
      </RouterLink>

      <nav class="navbar__nav">
        <RouterLink
          v-for="item in navItems"
          :key="item.to"
          :to="item.to"
          class="navbar__link"
          :class="{ active: isActive(item.to) }"
        >
          {{ item.label }}
        </RouterLink>
      </nav>

      <div class="navbar__right">
        <button
          v-if="variant === 'student'"
          type="button"
          class="navbar__bell"
          aria-label="通知"
          @click="goNotifications"
        >
          <svg viewBox="0 0 24 24" fill="none">
            <path
              d="M12 4a5 5 0 00-5 5v2.5c0 .8-.3 1.6-.9 2.2L5 15h14l-1.1-1.3c-.6-.6-.9-1.4-.9-2.2V9a5 5 0 00-5-5z"
              stroke="currentColor"
              stroke-width="1.6"
            />
            <path d="M10 17a2 2 0 004 0" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" />
          </svg>
          <span v-if="unreadCount > 0" class="navbar__dot" />
        </button>

        <div class="navbar__user" @click="menuOpen = !menuOpen" @keydown.escape="menuOpen = false">
          <span class="navbar__avatar" :style="{ background: user?.avatarColor || '#7c8cff' }">
            {{ avatarText }}
          </span>
          <span class="navbar__name">{{ user?.name || '学员' }}</span>
          <svg class="navbar__caret" viewBox="0 0 12 12" fill="none">
            <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" />
          </svg>
          <div v-if="menuOpen" class="navbar__menu">
            <button v-if="variant === 'student'" type="button" @click.stop="goProfile">个人中心</button>
            <button
              v-if="canManage && portalMode === 'student'"
              type="button"
              @click.stop="switchToAdmin"
            >
              切换到管理端
            </button>
            <button
              v-if="portalMode === 'admin'"
              type="button"
              @click.stop="switchToStudent"
            >
              返回学员端
            </button>
            <button type="button" @click.stop="onLogout">退出登录</button>
          </div>
        </div>
      </div>
    </div>
  </header>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { storeToRefs } from 'pinia'
import { useUserStore } from '@/stores/user'
import { useNotificationStore } from '@/stores/notification'

const props = withDefaults(
  defineProps<{
    variant?: 'student' | 'admin'
  }>(),
  { variant: 'student' },
)

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const { user, portalMode, canManage } = storeToRefs(userStore)
const notificationStore = useNotificationStore()
const { unreadCount } = storeToRefs(notificationStore)

const menuOpen = ref(false)

const brandTo = computed(() => (props.variant === 'admin' ? '/admin' : '/'))

const navItems = computed(() =>
  props.variant === 'admin'
    ? [
        { label: '首页', to: '/admin' },
        { label: '课程管理', to: '/admin/courses' },
        { label: '学员管理', to: '/admin/students' },
      ]
    : [
        { label: '首页', to: '/' },
        { label: '课程中心', to: '/courses' },
        { label: '我的课程', to: '/my-learning' },
      ],
)

const avatarText = computed(() => (user.value?.name || '学').slice(0, 1))

function isActive(to: string) {
  if (props.variant === 'admin') {
    if (to === '/admin') return route.path === '/admin'
    return route.path.startsWith(to)
  }
  if (to === '/') return route.path === '/'
  if (to === '/courses') {
    return route.path === '/courses' || route.path.startsWith('/course/')
  }
  return route.path.startsWith(to)
}

function goNotifications() {
  router.push('/notifications')
}

function goProfile() {
  menuOpen.value = false
  router.push('/profile')
}

function switchToAdmin() {
  menuOpen.value = false
  if (!userStore.enterAdmin()) return
  router.push('/admin')
}

function switchToStudent() {
  menuOpen.value = false
  userStore.enterStudent()
  router.push('/')
}

function onLogout() {
  menuOpen.value = false
  userStore.logout()
  router.push('/login')
}

function onDocClick(e: MouseEvent) {
  const target = e.target as HTMLElement
  if (!target.closest('.navbar__user')) {
    menuOpen.value = false
  }
}

onMounted(() => {
  document.addEventListener('click', onDocClick)
  if (props.variant === 'student') {
    notificationStore.refreshUnread()
  }
})
onUnmounted(() => document.removeEventListener('click', onDocClick))
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.navbar {
  position: sticky;
  top: 0;
  z-index: 100;
  height: $nav-height;
  background: #fff;
  border-bottom: 1px solid $border;
}

.navbar__inner {
  height: 100%;
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  align-items: center;
  gap: 16px;
}

.navbar__brand {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
  justify-self: start;
}

.navbar__logo-img {
  width: 40px;
  height: 40px;
  object-fit: contain;
  display: block;
  border-radius: 8px;
}

.navbar__title {
  font-size: 16px;
  font-weight: 700;
  color: $text-title;
  letter-spacing: 0.2px;

  @include mobile {
    display: none;
  }
}

.navbar__badge {
  height: 22px;
  padding: 0 8px;
  border-radius: 6px;
  background: $primary-light;
  color: $primary;
  font-size: 12px;
  font-weight: 600;
  display: inline-flex;
  align-items: center;

  @include mobile {
    display: none;
  }
}

.navbar__nav {
  display: flex;
  align-items: center;
  gap: 28px;
  justify-self: center;

  @include mobile {
    display: none;
  }
}

.navbar__link {
  position: relative;
  height: $nav-height;
  display: inline-flex;
  align-items: center;
  font-size: 15px;
  font-weight: 500;
  color: $text-secondary;
  transition: color 0.15s ease;

  &::after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 2px;
    background: transparent;
    border-radius: 2px 2px 0 0;
    transition: background 0.15s ease;
  }

  &:hover {
    color: $primary;
  }

  &.active {
    color: $primary;

    &::after {
      background: $primary;
    }
  }
}

.navbar__right {
  display: flex;
  align-items: center;
  gap: 16px;
  justify-self: end;
}

.navbar__bell {
  position: relative;
  width: 36px;
  height: 36px;
  border: none;
  border-radius: 50%;
  background: transparent;
  color: $text-secondary;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;

  svg {
    width: 20px;
    height: 20px;
  }

  &:hover {
    background: $primary-light;
    color: $primary;
  }
}

.navbar__dot {
  position: absolute;
  top: 8px;
  right: 8px;
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #ef4444;
  border: 1.5px solid #fff;
}

.navbar__user {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 4px 6px;
  border-radius: 8px;

  &:hover {
    background: #f5f7ff;
  }
}

.navbar__avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  color: #fff;
  font-size: 13px;
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.navbar__name {
  font-size: 14px;
  color: $text-body;
  font-weight: 500;

  @include mobile {
    display: none;
  }
}

.navbar__caret {
  width: 12px;
  height: 12px;
  color: $text-muted;
}

.navbar__menu {
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  min-width: 148px;
  background: #fff;
  border-radius: 10px;
  box-shadow: $shadow-hover;
  border: 1px solid $border;
  padding: 6px;
  z-index: 20;

  button {
    width: 100%;
    height: 36px;
    border: none;
    background: transparent;
    border-radius: 6px;
    text-align: left;
    padding: 0 12px;
    font-size: 14px;
    color: $text-body;
    cursor: pointer;

    &:hover {
      background: $primary-light;
      color: $primary;
    }
  }
}
</style>
