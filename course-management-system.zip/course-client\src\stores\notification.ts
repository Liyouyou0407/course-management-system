import { defineStore } from 'pinia'
import { ref } from 'vue'
import { fetchUnreadCount, markAllNotificationsRead } from '@/api/notifications'

export const useNotificationStore = defineStore('notification', () => {
  const unreadCount = ref(0)

  async function refreshUnread() {
    try {
      const data = await fetchUnreadCount()
      unreadCount.value = data.count
    } catch {
      /* ignore */
    }
  }

  async function markAllRead() {
    await markAllNotificationsRead()
    unreadCount.value = 0
  }

  return { unreadCount, refreshUnread, markAllRead }
})
