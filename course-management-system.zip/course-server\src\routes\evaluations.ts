import { Router } from 'express'
import { z } from 'zod'
import { prisma } from '../lib/prisma'
import { fail, ok } from '../lib/response'
import { authRequired, type AuthRequest } from '../middleware/auth'

const router = Router()

const scoreSchema = z.number().min(1).max(5)

router.get('/mine/:courseId', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const courseId = Number(req.params.courseId)
  const evaluation = await prisma.evaluation.findUnique({
    where: { courseId_studentId: { courseId, studentId: userId } },
  })
  if (!evaluation) return ok(res, null)
  return ok(res, {
    course_id: evaluation.courseId,
    score_experience: evaluation.scoreExperience,
    score_fluency: evaluation.scoreFluency,
    score_practicality: evaluation.scorePracticality,
    score_inspiration: evaluation.scoreInspiration,
    avg_score: evaluation.avgScore,
    feedback: evaluation.feedback,
    submitted_at: evaluation.submittedAt,
  })
})

router.post('/', authRequired, async (req: AuthRequest, res) => {
  const userId = req.userId!
  const schema = z.object({
    course_id: z.number().int().positive(),
    score_experience: scoreSchema,
    score_fluency: scoreSchema,
    score_practicality: scoreSchema,
    score_inspiration: scoreSchema,
    feedback: z.string().max(500).optional(),
  })
  const parsed = schema.safeParse(req.body)
  if (!parsed.success) return fail(res, '评分参数不合法')

  const courseId = parsed.data.course_id
  const enrollment = await prisma.enrollment.findUnique({
    where: { courseId_studentId: { courseId, studentId: userId } },
  })
  if (!enrollment || enrollment.status !== 'approved') {
    return fail(res, '请先报名该课程')
  }

  const progress = await prisma.learningProgress.findUnique({
    where: { userId_courseId: { userId, courseId } },
  })
  if (!progress || progress.progressPercent < 100) {
    return fail(res, '课程未完成，暂不可评价')
  }

  const existing = await prisma.evaluation.findUnique({
    where: { courseId_studentId: { courseId, studentId: userId } },
  })
  if (existing) return fail(res, '已评价过该课程，不可重复提交', 409, 409)

  const {
    score_experience,
    score_fluency,
    score_practicality,
    score_inspiration,
    feedback,
  } = parsed.data
  const avgScore =
    Math.round(
      ((score_experience + score_fluency + score_practicality + score_inspiration) / 4) *
        10,
    ) / 10

  const created = await prisma.evaluation.create({
    data: {
      courseId,
      studentId: userId,
      scoreExperience: score_experience,
      scoreFluency: score_fluency,
      scorePracticality: score_practicality,
      scoreInspiration: score_inspiration,
      avgScore,
      feedback,
    },
  })

  return ok(res, {
    course_id: created.courseId,
    avg_score: created.avgScore,
    submitted_at: created.submittedAt,
  })
})

export default router
