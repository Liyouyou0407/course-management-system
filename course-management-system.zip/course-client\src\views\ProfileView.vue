<template>
  <div class="page page-container">
    <div class="profile">
      <div class="profile__avatar" :style="{ background: user?.avatarColor }">
        {{ user?.name?.slice(0, 1) }}
      </div>
      <div>
        <h1>{{ user?.name }}</h1>
        <p>账号：{{ user?.username }}</p>
        <p>部门：{{ user?.departmentName || '未分配部门' }}</p>
      </div>
    </div>
    <div class="actions">
      <RouterLink to="/my-learning" class="btn btn-soft">我的课程</RouterLink>
      <button type="button" class="btn btn-outline" @click="logout">退出登录</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { storeToRefs } from 'pinia'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const userStore = useUserStore()
const { user } = storeToRefs(userStore)

onMounted(() => {
  userStore.fetchMe()
})

function logout() {
  userStore.logout()
  router.push('/login')
}
</script>

<style scoped lang="scss">
@use '@/styles/mixins.scss' as *;

.profile {
  @include card;
  display: flex;
  align-items: center;
  gap: 20px;
  padding: 28px;
  background: #fff;
  margin-bottom: 20px;

  h1 {
    font-size: 22px;
    margin-bottom: 8px;
    color: $text-title;
  }

  p {
    color: $text-secondary;
    margin-bottom: 4px;
  }
}

.profile__avatar {
  width: 72px;
  height: 72px;
  border-radius: 50%;
  color: #fff;
  font-size: 28px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
}

.actions {
  display: flex;
  gap: 12px;
}
</style>
